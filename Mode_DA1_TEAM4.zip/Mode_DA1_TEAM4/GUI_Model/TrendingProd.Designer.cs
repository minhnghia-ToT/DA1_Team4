﻿namespace GUI_Model
{
    partial class TrendingProd
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(TrendingProd));
            button5 = new Button();
            dtgv = new DataGridView();
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            label5 = new Label();
            txtID = new TextBox();
            txtName = new TextBox();
            txtprice = new TextBox();
            txtquantity = new TextBox();
            txtdes = new TextBox();
            ((System.ComponentModel.ISupportInitialize)dtgv).BeginInit();
            SuspendLayout();
            // 
            // button5
            // 
            button5.BackColor = Color.LightCyan;
            button5.Font = new Font("Agency FB", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button5.ForeColor = Color.LightSeaGreen;
            button5.Image = (Image)resources.GetObject("button5.Image");
            button5.Location = new Point(42, 401);
            button5.Name = "button5";
            button5.Size = new Size(1268, 96);
            button5.TabIndex = 16;
            button5.TextAlign = ContentAlignment.BottomRight;
            button5.UseVisualStyleBackColor = false;
            button5.Click += button5_Click;
            // 
            // dtgv
            // 
            dtgv.BackgroundColor = SystemColors.GradientActiveCaption;
            dtgv.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dtgv.Location = new Point(42, 207);
            dtgv.Name = "dtgv";
            dtgv.RowHeadersWidth = 51;
            dtgv.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dtgv.Size = new Size(1268, 188);
            dtgv.TabIndex = 17;
            dtgv.CellContentClick += dataGridView1_CellContentClick;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = Color.RoyalBlue;
            label1.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.ForeColor = Color.White;
            label1.Location = new Point(42, 55);
            label1.Name = "label1";
            label1.Size = new Size(113, 28);
            label1.TabIndex = 18;
            label1.Text = "Product ID";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.BackColor = Color.RoyalBlue;
            label2.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label2.ForeColor = Color.White;
            label2.Location = new Point(42, 130);
            label2.Name = "label2";
            label2.Size = new Size(68, 28);
            label2.TabIndex = 18;
            label2.Text = "Name";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.BackColor = Color.RoyalBlue;
            label3.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label3.ForeColor = Color.White;
            label3.Location = new Point(878, 55);
            label3.Name = "label3";
            label3.Size = new Size(94, 28);
            label3.TabIndex = 18;
            label3.Text = "Describe";
            label3.Click += label3_Click;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.BackColor = Color.RoyalBlue;
            label4.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label4.ForeColor = Color.White;
            label4.Location = new Point(478, 53);
            label4.Name = "label4";
            label4.Size = new Size(59, 28);
            label4.TabIndex = 18;
            label4.Text = "Price";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.BackColor = Color.RoyalBlue;
            label5.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label5.ForeColor = Color.White;
            label5.Location = new Point(478, 126);
            label5.Name = "label5";
            label5.Size = new Size(95, 28);
            label5.TabIndex = 18;
            label5.Text = "Quantity";
            // 
            // txtID
            // 
            txtID.BackColor = SystemColors.Highlight;
            txtID.Font = new Font("Segoe UI", 10.2F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txtID.Location = new Point(161, 55);
            txtID.Name = "txtID";
            txtID.Size = new Size(234, 30);
            txtID.TabIndex = 19;
            // 
            // txtName
            // 
            txtName.BackColor = SystemColors.Highlight;
            txtName.Font = new Font("Segoe UI", 10.2F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txtName.Location = new Point(116, 130);
            txtName.Name = "txtName";
            txtName.Size = new Size(279, 30);
            txtName.TabIndex = 19;
            // 
            // txtprice
            // 
            txtprice.BackColor = SystemColors.Highlight;
            txtprice.Font = new Font("Segoe UI", 10.2F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txtprice.Location = new Point(543, 51);
            txtprice.Name = "txtprice";
            txtprice.Size = new Size(293, 30);
            txtprice.TabIndex = 19;
            // 
            // txtquantity
            // 
            txtquantity.BackColor = SystemColors.Highlight;
            txtquantity.Font = new Font("Segoe UI", 10.2F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txtquantity.Location = new Point(579, 124);
            txtquantity.Name = "txtquantity";
            txtquantity.Size = new Size(257, 30);
            txtquantity.TabIndex = 19;
            // 
            // txtdes
            // 
            txtdes.BackColor = SystemColors.Highlight;
            txtdes.Font = new Font("Segoe UI", 10.2F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txtdes.Location = new Point(978, 51);
            txtdes.MaxLength = 400;
            txtdes.Multiline = true;
            txtdes.Name = "txtdes";
            txtdes.Size = new Size(332, 101);
            txtdes.TabIndex = 19;
            // 
            // TrendingProd
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.MediumBlue;
            BackgroundImage = (Image)resources.GetObject("$this.BackgroundImage");
            ClientSize = new Size(1353, 538);
            Controls.Add(txtquantity);
            Controls.Add(txtName);
            Controls.Add(txtdes);
            Controls.Add(txtprice);
            Controls.Add(txtID);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(dtgv);
            Controls.Add(button5);
            Name = "TrendingProd";
            Text = "TrendingProd";
            Load += TrendingProd_Load;
            ((System.ComponentModel.ISupportInitialize)dtgv).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button button5;
        private DataGridView dtgv;
        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private Label label5;
        private TextBox txtID;
        private TextBox txtName;
        private TextBox txtprice;
        private TextBox txtquantity;
        private TextBox txtdes;
    }
}