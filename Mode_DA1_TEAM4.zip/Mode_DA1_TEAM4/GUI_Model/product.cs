﻿using BUS;
using DAL;
using DTO;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Diagnostics.Eventing.Reader;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ListView;

namespace GUI_Model
{
    public partial class product : Form
    {
        DAL_Product dal_pro = new DAL_Product();
        public product()
        {
            InitializeComponent();
            LoadGridview();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
        private void LoadGridview()
        {
            dtgvProd.DataSource = dal_pro.getProd();
            dtgvProd.Columns[0].HeaderText = "IDproduct";
            dtgvProd.Columns[1].HeaderText = "Image";
            dtgvProd.Columns[2].HeaderText = "Name";
            dtgvProd.Columns[3].HeaderText = "Describe";
            dtgvProd.Columns[4].HeaderText = "Price";
            dtgvProd.Columns[5].HeaderText = "Quantity";
        }


        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            admin ad = new admin();
            ad.Show();
            this.Close();
        }

        private void btnThem_Click(object sender, EventArgs e)
        {


            /*            txtimg.Text = null;*/
            txtname.Text = null;
            txtdescribe.Text = null;
            txtprice.Text = null;
            txtquantity.Text = null;



            btnLuu.Enabled = true;
            btnSua.Enabled = false;
            btnXoa.Enabled = false;

        }
        public bool IsValidPositiveInteger(string inputString)
        {
            // Combine parsing and check into a single condition
            if (int.TryParse(inputString, out int result) && result > 0)
            {
                return true;
            }
            else
            {
                // Optional: Provide a more specific error message
                // MessageBox.Show("Invalid input. Please enter a positive integer.");
                return false;
            }
        }

        private void btnLuu_Click(object sender, EventArgs e)
        {
            // 1. Input Validation (You already have good validation!) 
            if (txtname.Text.Trim().Length == 0)
            {
                MessageBox.Show("Bạn phải nhập IDsanpham", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                txtname.Focus();
                return;
            }
            else if (!IsValidPositiveInteger(txtname.Text.Trim()))
            {
                MessageBox.Show("Bạn phải nhập đúng định dạng IDsanpham", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                txtname.Focus();
                return;
            }

            // 2. Get Values from ALL Input Fields (including Image if applicable)
            // Assuming txtname.Text holds the ID, but adjust based on your form
            // Also, make sure you have TextBoxes named appropriately for other properties
            int productId;
            if (!int.TryParse(txtname.Text.Trim(), out productId))
            {
                MessageBox.Show("Invalid ID format.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            string imageName = txtimg.Text.Trim(); // Get image name/path 
            string productName = txtname.Text.Trim(); // Get product name
                                                      // ... Get values for other properties from their respective input controls ...

            // 3. Create and Populate the DTO_product Object
            DTO_product prod = new DTO_product(
                productId,
                imageName,
                productName
            // ... Pass values for other properties here ...
            );


            // 4. Insert Product using DAL
            if (!dal_pro.Insert_SanPham(prod))
            {
                MessageBox.Show("Thêm sản phẩm không thành công");
            }
            else
            {
                MessageBox.Show("Thêm sản phẩm thành công");
                LoadGridview();
                // ... Optional: Clear input fields after successful insert ... 
            }
        }

        private void product_Load(object sender, EventArgs e)
        {
            InitializeComponent();
            LoadGridview();
        }

        private void btaddimg_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Filter = "Image Files|*.jpg;*.jpeg;*.png;*.bmp";

            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                pb1.Image = new System.Drawing.Bitmap(openFileDialog.FileName);
            }
        }

        private void btnSua_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtIDprod.Text) ||
          string.IsNullOrWhiteSpace(txtname.Text) ||
          string.IsNullOrWhiteSpace(txtdescribe.Text) ||
          string.IsNullOrWhiteSpace(txtimg.Text) ||
          string.IsNullOrWhiteSpace(txtprice.Text) ||
          string.IsNullOrWhiteSpace(txtquantity.Text))
            {
                MessageBox.Show("Please fill in all fields.");
                return;
            }

            if (!int.TryParse(txtIDprod.Text, out int id))
            {
                MessageBox.Show("Invalid ID. Please enter a valid numeric ID.");
                return;
            }

            if (!int.TryParse(txtprice.Text, out int price))
            {
                MessageBox.Show("Invalid price. Please enter a valid numeric price.");
                return;
            }

            if (!int.TryParse(txtquantity.Text, out int quantity))
            {
                MessageBox.Show("Invalid quantity. Please enter a valid numeric quantity.");
                return;
            }

            string name = txtname.Text;
            string describe = txtdescribe.Text;
            string image = txtimg.Text;

            DTO_product product = new DTO_product(id, name, describe, image, price, quantity);
            DAL_Product dalProduct = new DAL_Product();

            if (dalProduct.Update_SanPham(product))
            {
                MessageBox.Show("Product updated successfully!");
            }
            else
            {
                MessageBox.Show("Failed to update product.");
            }
        }
    }
}
