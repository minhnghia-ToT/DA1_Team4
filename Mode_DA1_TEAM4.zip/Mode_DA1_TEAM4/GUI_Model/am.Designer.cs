﻿namespace GUI_Model
{
    partial class am
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(am));
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            label5 = new Label();
            txtname = new TextBox();
            txtEmail = new TextBox();
            txtPass = new TextBox();
            groupBox1 = new GroupBox();
            rbAdmin = new RadioButton();
            rbStaff = new RadioButton();
            dtgvStaff = new DataGridView();
            txttimKiem = new TextBox();
            btnDong = new Button();
            btnXoa = new Button();
            btnSua = new Button();
            btnLuu = new Button();
            btnBoqua = new Button();
            btnDanhsach = new Button();
            btnTimkiem = new Button();
            btnThem = new Button();
            btnBack = new Button();
            pictureBox1 = new PictureBox();
            groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dtgvStaff).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Arial", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.ForeColor = Color.DodgerBlue;
            label1.Location = new Point(484, 22);
            label1.Name = "label1";
            label1.Size = new Size(399, 35);
            label1.TabIndex = 0;
            label1.Text = "Staff Account Management";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label2.ForeColor = Color.DodgerBlue;
            label2.Location = new Point(89, 85);
            label2.Name = "label2";
            label2.Size = new Size(120, 28);
            label2.TabIndex = 1;
            label2.Text = "Staff Name";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label3.ForeColor = Color.DodgerBlue;
            label3.Location = new Point(155, 164);
            label3.Name = "label3";
            label3.Size = new Size(54, 28);
            label3.TabIndex = 1;
            label3.Text = "Role";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label4.ForeColor = Color.DodgerBlue;
            label4.Location = new Point(726, 85);
            label4.Name = "label4";
            label4.Size = new Size(64, 28);
            label4.TabIndex = 1;
            label4.Text = "Email";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label5.ForeColor = Color.DodgerBlue;
            label5.Location = new Point(689, 160);
            label5.Name = "label5";
            label5.Size = new Size(101, 28);
            label5.TabIndex = 1;
            label5.Text = "Password";
            // 
            // txtname
            // 
            txtname.Font = new Font("Arial", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            txtname.Location = new Point(244, 83);
            txtname.Name = "txtname";
            txtname.Size = new Size(322, 34);
            txtname.TabIndex = 2;
            // 
            // txtEmail
            // 
            txtEmail.Font = new Font("Arial", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            txtEmail.Location = new Point(844, 85);
            txtEmail.Name = "txtEmail";
            txtEmail.Size = new Size(322, 34);
            txtEmail.TabIndex = 2;
            // 
            // txtPass
            // 
            txtPass.Font = new Font("Arial", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            txtPass.Location = new Point(844, 158);
            txtPass.Name = "txtPass";
            txtPass.Size = new Size(322, 34);
            txtPass.TabIndex = 2;
            txtPass.TextChanged += txtPass_TextChanged;
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(rbAdmin);
            groupBox1.Controls.Add(rbStaff);
            groupBox1.Location = new Point(244, 135);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(322, 88);
            groupBox1.TabIndex = 3;
            groupBox1.TabStop = false;
            // 
            // rbAdmin
            // 
            rbAdmin.AutoSize = true;
            rbAdmin.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
            rbAdmin.ForeColor = Color.Black;
            rbAdmin.Location = new Point(193, 27);
            rbAdmin.Name = "rbAdmin";
            rbAdmin.Size = new Size(95, 32);
            rbAdmin.TabIndex = 0;
            rbAdmin.TabStop = true;
            rbAdmin.Text = "Admin";
            rbAdmin.UseVisualStyleBackColor = true;
            // 
            // rbStaff
            // 
            rbStaff.AutoSize = true;
            rbStaff.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
            rbStaff.ForeColor = Color.Black;
            rbStaff.Location = new Point(39, 27);
            rbStaff.Name = "rbStaff";
            rbStaff.Size = new Size(79, 32);
            rbStaff.TabIndex = 0;
            rbStaff.TabStop = true;
            rbStaff.Text = "Staff";
            rbStaff.UseVisualStyleBackColor = true;
            // 
            // dtgvStaff
            // 
            dtgvStaff.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dtgvStaff.GridColor = SystemColors.ActiveCaptionText;
            dtgvStaff.Location = new Point(1, 250);
            dtgvStaff.Name = "dtgvStaff";
            dtgvStaff.RowHeadersWidth = 51;
            dtgvStaff.Size = new Size(1323, 188);
            dtgvStaff.TabIndex = 4;
            dtgvStaff.CellContentClick += dtgvStaff_CellContentClick;
            dtgvStaff.Click += dtgvStaff_Click;
            // 
            // txttimKiem
            // 
            txttimKiem.BackColor = Color.LightGray;
            txttimKiem.Font = new Font("Microsoft Sans Serif", 10.2F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txttimKiem.Location = new Point(1067, 476);
            txttimKiem.Margin = new Padding(4, 5, 4, 5);
            txttimKiem.Name = "txttimKiem";
            txttimKiem.Size = new Size(256, 27);
            txttimKiem.TabIndex = 43;
            txttimKiem.Text = "Enter staff name...";
            // 
            // btnDong
            // 
            btnDong.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnDong.ForeColor = Color.Black;
            btnDong.Image = (Image)resources.GetObject("btnDong.Image");
            btnDong.ImageAlign = ContentAlignment.MiddleLeft;
            btnDong.Location = new Point(721, 457);
            btnDong.Margin = new Padding(4, 5, 4, 5);
            btnDong.Name = "btnDong";
            btnDong.Size = new Size(101, 59);
            btnDong.TabIndex = 42;
            btnDong.Text = "Close";
            btnDong.UseVisualStyleBackColor = true;
            btnDong.Click += btnDong_Click;
            // 
            // btnXoa
            // 
            btnXoa.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnXoa.ForeColor = Color.Black;
            btnXoa.Image = (Image)resources.GetObject("btnXoa.Image");
            btnXoa.ImageAlign = ContentAlignment.MiddleLeft;
            btnXoa.Location = new Point(119, 457);
            btnXoa.Margin = new Padding(4, 5, 4, 5);
            btnXoa.Name = "btnXoa";
            btnXoa.Size = new Size(101, 59);
            btnXoa.TabIndex = 36;
            btnXoa.Text = "Delete";
            btnXoa.UseVisualStyleBackColor = true;
            btnXoa.Click += btnXoa_Click;
            // 
            // btnSua
            // 
            btnSua.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnSua.ForeColor = Color.Black;
            btnSua.Image = (Image)resources.GetObject("btnSua.Image");
            btnSua.ImageAlign = ContentAlignment.MiddleLeft;
            btnSua.Location = new Point(244, 457);
            btnSua.Margin = new Padding(4, 5, 4, 5);
            btnSua.Name = "btnSua";
            btnSua.Size = new Size(101, 59);
            btnSua.TabIndex = 37;
            btnSua.Text = "Update";
            btnSua.UseVisualStyleBackColor = true;
            btnSua.Click += btnSua_Click;
            // 
            // btnLuu
            // 
            btnLuu.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnLuu.ForeColor = Color.Black;
            btnLuu.Image = (Image)resources.GetObject("btnLuu.Image");
            btnLuu.ImageAlign = ContentAlignment.MiddleLeft;
            btnLuu.Location = new Point(356, 457);
            btnLuu.Margin = new Padding(4, 5, 4, 5);
            btnLuu.Name = "btnLuu";
            btnLuu.Size = new Size(101, 59);
            btnLuu.TabIndex = 38;
            btnLuu.Text = "Save";
            btnLuu.UseVisualStyleBackColor = true;
            btnLuu.Click += btnLuu_Click;
            // 
            // btnBoqua
            // 
            btnBoqua.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnBoqua.ForeColor = Color.Black;
            btnBoqua.Image = (Image)resources.GetObject("btnBoqua.Image");
            btnBoqua.ImageAlign = ContentAlignment.MiddleLeft;
            btnBoqua.Location = new Point(475, 457);
            btnBoqua.Margin = new Padding(4, 5, 4, 5);
            btnBoqua.Name = "btnBoqua";
            btnBoqua.Size = new Size(101, 59);
            btnBoqua.TabIndex = 39;
            btnBoqua.Text = "Refresh";
            btnBoqua.UseVisualStyleBackColor = true;
            btnBoqua.Click += btnBoqua_Click;
            // 
            // btnDanhsach
            // 
            btnDanhsach.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnDanhsach.ForeColor = Color.Black;
            btnDanhsach.Image = (Image)resources.GetObject("btnDanhsach.Image");
            btnDanhsach.ImageAlign = ContentAlignment.MiddleLeft;
            btnDanhsach.Location = new Point(595, 457);
            btnDanhsach.Margin = new Padding(4, 5, 4, 5);
            btnDanhsach.Name = "btnDanhsach";
            btnDanhsach.Size = new Size(101, 59);
            btnDanhsach.TabIndex = 41;
            btnDanhsach.Text = "List";
            btnDanhsach.UseVisualStyleBackColor = true;
            // 
            // btnTimkiem
            // 
            btnTimkiem.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnTimkiem.ForeColor = Color.Black;
            btnTimkiem.Image = (Image)resources.GetObject("btnTimkiem.Image");
            btnTimkiem.ImageAlign = ContentAlignment.MiddleLeft;
            btnTimkiem.Location = new Point(958, 457);
            btnTimkiem.Margin = new Padding(4, 5, 4, 5);
            btnTimkiem.Name = "btnTimkiem";
            btnTimkiem.Size = new Size(101, 59);
            btnTimkiem.TabIndex = 40;
            btnTimkiem.Text = "Search";
            btnTimkiem.UseVisualStyleBackColor = true;
            btnTimkiem.Click += btnTimkiem_Click;
            // 
            // btnThem
            // 
            btnThem.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnThem.ForeColor = Color.Black;
            btnThem.Image = (Image)resources.GetObject("btnThem.Image");
            btnThem.ImageAlign = ContentAlignment.MiddleLeft;
            btnThem.Location = new Point(1, 457);
            btnThem.Margin = new Padding(4, 5, 4, 5);
            btnThem.Name = "btnThem";
            btnThem.Size = new Size(101, 59);
            btnThem.TabIndex = 35;
            btnThem.Text = "Add";
            btnThem.UseVisualStyleBackColor = true;
            btnThem.Click += btnThem_Click;
            // 
            // btnBack
            // 
            btnBack.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnBack.ForeColor = Color.Black;
            btnBack.ImageAlign = ContentAlignment.MiddleLeft;
            btnBack.Location = new Point(844, 457);
            btnBack.Margin = new Padding(4, 5, 4, 5);
            btnBack.Name = "btnBack";
            btnBack.Size = new Size(101, 59);
            btnBack.TabIndex = 40;
            btnBack.Text = "Back";
            btnBack.UseVisualStyleBackColor = true;
            btnBack.Click += btnBack_Click;
            // 
            // pictureBox1
            // 
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(1257, 12);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(66, 62);
            pictureBox1.TabIndex = 44;
            pictureBox1.TabStop = false;
            pictureBox1.Click += pictureBox1_Click;
            // 
            // am
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.ButtonFace;
            ClientSize = new Size(1336, 734);
            Controls.Add(pictureBox1);
            Controls.Add(txttimKiem);
            Controls.Add(btnDong);
            Controls.Add(btnXoa);
            Controls.Add(btnSua);
            Controls.Add(btnLuu);
            Controls.Add(btnBoqua);
            Controls.Add(btnDanhsach);
            Controls.Add(btnBack);
            Controls.Add(btnTimkiem);
            Controls.Add(btnThem);
            Controls.Add(dtgvStaff);
            Controls.Add(groupBox1);
            Controls.Add(txtPass);
            Controls.Add(txtEmail);
            Controls.Add(txtname);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            ForeColor = Color.Black;
            Name = "am";
            Text = "Account management";
            Load += am_Load;
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)dtgvStaff).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private Label label5;
        private TextBox txtname;
        private TextBox txtEmail;
        private TextBox txtPass;
        private GroupBox groupBox1;
        private RadioButton rbAdmin;
        private RadioButton rbStaff;
        private DataGridView dtgvStaff;
        private TextBox txttimKiem;
        private Button btnDong;
        private Button btnXoa;
        private Button btnSua;
        private Button btnLuu;
        private Button btnBoqua;
        private Button btnDanhsach;
        private Button btnTimkiem;
        private Button btnThem;
        private Button btnBack;
        private PictureBox pictureBox1;
    }
}