﻿namespace GUI_Model
{
    partial class Cart
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Cart));
            bunifuDoughnutChart1 = new Bunifu.Charts.WinForms.ChartTypes.BunifuDoughnutChart(components);
            btnThoat = new Button();
            groupBox1 = new GroupBox();
            label1 = new Label();
            txtIDGioHang = new TextBox();
            dateTimePickerNgayTao = new DateTimePicker();
            txtIDNhanVien = new TextBox();
            label3 = new Label();
            label2 = new Label();
            btnXoa = new Button();
            btnSua = new Button();
            btnThem = new Button();
            dtgvdal = new DataGridView();
            btnChiTietGioHang = new Button();
            btnLamMoi = new Button();
            groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dtgvdal).BeginInit();
            SuspendLayout();
            // 
            // bunifuDoughnutChart1
            // 
            bunifuDoughnutChart1.BackgroundColor = (List<Color>)resources.GetObject("bunifuDoughnutChart1.BackgroundColor");
            bunifuDoughnutChart1.BorderColor = (List<Color>)resources.GetObject("bunifuDoughnutChart1.BorderColor");
            bunifuDoughnutChart1.BorderWidth = 0;
            bunifuDoughnutChart1.Data = (List<double>)resources.GetObject("bunifuDoughnutChart1.Data");
            bunifuDoughnutChart1.HoverBackgroundColor = Color.Empty;
            bunifuDoughnutChart1.HoverBorderColor = Color.Empty;
            bunifuDoughnutChart1.HoverBorderWidth = 0;
            bunifuDoughnutChart1.Label = "label here";
            bunifuDoughnutChart1.TargetCanvas = null;
            // 
            // btnThoat
            // 
            btnThoat.BackColor = SystemColors.ActiveCaption;
            btnThoat.Font = new Font("Candara", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnThoat.Location = new Point(646, 30);
            btnThoat.Margin = new Padding(4, 4, 4, 4);
            btnThoat.Name = "btnThoat";
            btnThoat.Size = new Size(174, 46);
            btnThoat.TabIndex = 24;
            btnThoat.Text = "Thoát";
            btnThoat.UseVisualStyleBackColor = false;
            btnThoat.Click += btnThoat_Click_1;
            // 
            // groupBox1
            // 
            groupBox1.BackColor = SystemColors.ActiveCaption;
            groupBox1.Controls.Add(label1);
            groupBox1.Controls.Add(txtIDGioHang);
            groupBox1.Controls.Add(dateTimePickerNgayTao);
            groupBox1.Controls.Add(txtIDNhanVien);
            groupBox1.Controls.Add(label3);
            groupBox1.Controls.Add(label2);
            groupBox1.Font = new Font("Candara", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            groupBox1.Location = new Point(46, 96);
            groupBox1.Margin = new Padding(4, 4, 4, 4);
            groupBox1.Name = "groupBox1";
            groupBox1.Padding = new Padding(4, 4, 4, 4);
            groupBox1.Size = new Size(556, 321);
            groupBox1.TabIndex = 19;
            groupBox1.TabStop = false;
            groupBox1.Text = "Chi tiết giỏ hàng";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Candara", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(38, 164);
            label1.Margin = new Padding(4, 0, 4, 0);
            label1.Name = "label1";
            label1.Size = new Size(168, 35);
            label1.TabIndex = 10;
            label1.Text = "ID Giỏ Hàng :";
            // 
            // txtIDGioHang
            // 
            txtIDGioHang.Location = new Point(214, 159);
            txtIDGioHang.Margin = new Padding(4, 4, 4, 4);
            txtIDGioHang.Name = "txtIDGioHang";
            txtIDGioHang.Size = new Size(284, 41);
            txtIDGioHang.TabIndex = 9;
            // 
            // dateTimePickerNgayTao
            // 
            dateTimePickerNgayTao.Location = new Point(214, 240);
            dateTimePickerNgayTao.Margin = new Padding(4, 5, 4, 5);
            dateTimePickerNgayTao.Name = "dateTimePickerNgayTao";
            dateTimePickerNgayTao.Size = new Size(284, 41);
            dateTimePickerNgayTao.TabIndex = 8;
            // 
            // txtIDNhanVien
            // 
            txtIDNhanVien.Location = new Point(214, 70);
            txtIDNhanVien.Margin = new Padding(4, 4, 4, 4);
            txtIDNhanVien.Name = "txtIDNhanVien";
            txtIDNhanVien.Size = new Size(284, 41);
            txtIDNhanVien.TabIndex = 5;
            txtIDNhanVien.TextChanged += txtIDNhanVien_TextChanged;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Candara", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label3.Location = new Point(76, 251);
            label3.Margin = new Padding(4, 0, 4, 0);
            label3.Name = "label3";
            label3.Size = new Size(130, 35);
            label3.TabIndex = 2;
            label3.Text = "Ngày tạo:";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Candara", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label2.Location = new Point(38, 81);
            label2.Margin = new Padding(4, 0, 4, 0);
            label2.Name = "label2";
            label2.Size = new Size(175, 35);
            label2.TabIndex = 1;
            label2.Text = "ID Nhân Viên:";
            // 
            // btnXoa
            // 
            btnXoa.BackColor = SystemColors.ActiveCaption;
            btnXoa.Font = new Font("Candara", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnXoa.Location = new Point(646, 305);
            btnXoa.Margin = new Padding(4, 4, 4, 4);
            btnXoa.Name = "btnXoa";
            btnXoa.Size = new Size(174, 46);
            btnXoa.TabIndex = 21;
            btnXoa.Text = "Xóa";
            btnXoa.UseVisualStyleBackColor = false;
            btnXoa.Click += btnXoa_Click_1;
            // 
            // btnSua
            // 
            btnSua.BackColor = SystemColors.ActiveCaption;
            btnSua.Font = new Font("Candara", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnSua.Location = new Point(646, 235);
            btnSua.Margin = new Padding(4, 4, 4, 4);
            btnSua.Name = "btnSua";
            btnSua.Size = new Size(174, 46);
            btnSua.TabIndex = 22;
            btnSua.Text = "Sửa";
            btnSua.UseVisualStyleBackColor = false;
            btnSua.Click += btnSua_Click_1;
            // 
            // btnThem
            // 
            btnThem.BackColor = SystemColors.ActiveCaption;
            btnThem.Font = new Font("Candara", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnThem.Location = new Point(646, 166);
            btnThem.Margin = new Padding(4, 4, 4, 4);
            btnThem.Name = "btnThem";
            btnThem.Size = new Size(174, 46);
            btnThem.TabIndex = 27;
            btnThem.Text = "Thêm";
            btnThem.UseVisualStyleBackColor = false;
            btnThem.Click += btnThem_Click;
            // 
            // dtgvdal
            // 
            dtgvdal.BackgroundColor = SystemColors.ActiveCaption;
            dtgvdal.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dtgvdal.Location = new Point(46, 494);
            dtgvdal.Margin = new Padding(4, 4, 4, 4);
            dtgvdal.Name = "dtgvdal";
            dtgvdal.RowHeadersWidth = 51;
            dtgvdal.Size = new Size(766, 384);
            dtgvdal.TabIndex = 0;
            dtgvdal.CellContentClick += dtgvdal_CellContentClick_1;
            // 
            // btnChiTietGioHang
            // 
            btnChiTietGioHang.BackColor = SystemColors.ActiveCaption;
            btnChiTietGioHang.Font = new Font("Candara", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnChiTietGioHang.Location = new Point(646, 96);
            btnChiTietGioHang.Margin = new Padding(4, 4, 4, 4);
            btnChiTietGioHang.Name = "btnChiTietGioHang";
            btnChiTietGioHang.Size = new Size(166, 46);
            btnChiTietGioHang.TabIndex = 28;
            btnChiTietGioHang.Text = "Chi tiết giỏ hàng";
            btnChiTietGioHang.UseVisualStyleBackColor = false;
            btnChiTietGioHang.Click += btnChiTietGioHang_Click;
            // 
            // btnLamMoi
            // 
            btnLamMoi.BackColor = SystemColors.ActiveCaption;
            btnLamMoi.Font = new Font("Candara", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnLamMoi.Location = new Point(646, 371);
            btnLamMoi.Margin = new Padding(4, 4, 4, 4);
            btnLamMoi.Name = "btnLamMoi";
            btnLamMoi.Size = new Size(174, 46);
            btnLamMoi.TabIndex = 35;
            btnLamMoi.Text = "Làm mới";
            btnLamMoi.UseVisualStyleBackColor = false;
            btnLamMoi.Click += btnLamMoi_Click;
            // 
            // Cart
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(849, 929);
            Controls.Add(btnLamMoi);
            Controls.Add(btnChiTietGioHang);
            Controls.Add(dtgvdal);
            Controls.Add(btnThem);
            Controls.Add(btnThoat);
            Controls.Add(groupBox1);
            Controls.Add(btnXoa);
            Controls.Add(btnSua);
            Margin = new Padding(4, 5, 4, 5);
            Name = "Cart";
            Text = "Cart";
            Load += Cart_Load_1;
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)dtgvdal).EndInit();
            ResumeLayout(false);
        }

        #endregion
        private Bunifu.Charts.WinForms.ChartTypes.BunifuDoughnutChart bunifuDoughnutChart1;
        private Button btnThoat;
        private GroupBox groupBox1;
        private DateTimePicker dateTimePickerNgayTao;
        private TextBox txtIDNhanVien;
        private Label label3;
        private Label label2;
        private Button btnXoa;
        private Button btnSua;
        private Button btnThem;
        private DataGridView dtgvdal;
        private TextBox txtIDGioHang;
        private Label label1;
        private Button btnChiTietGioHang;
        private Button btnLamMoi;
    }
}