﻿namespace GUI_Model
{
    partial class ChiCart
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            dtgvdal = new DataGridView();
            btnThem = new Button();
            groupBox1 = new GroupBox();
            label5 = new Label();
            txtGia = new TextBox();
            label4 = new Label();
            txtIDSanPham = new TextBox();
            txtSoLuong = new TextBox();
            label1 = new Label();
            txtIDGioHang = new TextBox();
            txtIDChiTietGioHang = new TextBox();
            label3 = new Label();
            label2 = new Label();
            btnXoa = new Button();
            btnSua = new Button();
            btnThoat = new Button();
            btnLamMoi = new Button();
            ((System.ComponentModel.ISupportInitialize)dtgvdal).BeginInit();
            groupBox1.SuspendLayout();
            SuspendLayout();
            // 
            // dtgvdal
            // 
            dtgvdal.BackgroundColor = SystemColors.ActiveCaption;
            dtgvdal.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dtgvdal.Location = new Point(41, 367);
            dtgvdal.Name = "dtgvdal";
            dtgvdal.RowHeadersWidth = 51;
            dtgvdal.Size = new Size(975, 208);
            dtgvdal.TabIndex = 28;
            dtgvdal.CellContentClick += dtgvdal_CellContentClick;
            // 
            // btnThem
            // 
            btnThem.BackColor = SystemColors.ActiveCaption;
            btnThem.Font = new Font("Candara", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnThem.Location = new Point(41, 288);
            btnThem.Name = "btnThem";
            btnThem.Size = new Size(139, 37);
            btnThem.TabIndex = 32;
            btnThem.Text = "Thêm";
            btnThem.UseVisualStyleBackColor = false;
            btnThem.Click += btnThem_Click;
            // 
            // groupBox1
            // 
            groupBox1.BackColor = SystemColors.ActiveCaption;
            groupBox1.Controls.Add(label5);
            groupBox1.Controls.Add(txtGia);
            groupBox1.Controls.Add(label4);
            groupBox1.Controls.Add(txtIDSanPham);
            groupBox1.Controls.Add(txtSoLuong);
            groupBox1.Controls.Add(label1);
            groupBox1.Controls.Add(txtIDGioHang);
            groupBox1.Controls.Add(txtIDChiTietGioHang);
            groupBox1.Controls.Add(label3);
            groupBox1.Controls.Add(label2);
            groupBox1.Font = new Font("Candara", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            groupBox1.Location = new Point(41, 12);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(975, 257);
            groupBox1.TabIndex = 29;
            groupBox1.TabStop = false;
            groupBox1.Text = "Chi tiết giỏ hàng";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Candara", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label5.Location = new Point(551, 131);
            label5.Name = "label5";
            label5.Size = new Size(49, 28);
            label5.TabIndex = 15;
            label5.Text = "Giá:";
            label5.Click += label5_Click;
            // 
            // txtGia
            // 
            txtGia.Location = new Point(698, 128);
            txtGia.Name = "txtGia";
            txtGia.Size = new Size(228, 36);
            txtGia.TabIndex = 14;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Candara", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label4.Location = new Point(551, 60);
            label4.Name = "label4";
            label4.Size = new Size(141, 28);
            label4.TabIndex = 13;
            label4.Text = "ID Sản Phẩm:";
            // 
            // txtIDSanPham
            // 
            txtIDSanPham.Location = new Point(698, 57);
            txtIDSanPham.Name = "txtIDSanPham";
            txtIDSanPham.Size = new Size(228, 36);
            txtIDSanPham.TabIndex = 12;
            // 
            // txtSoLuong
            // 
            txtSoLuong.Location = new Point(243, 201);
            txtSoLuong.Name = "txtSoLuong";
            txtSoLuong.Size = new Size(228, 36);
            txtSoLuong.TabIndex = 11;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Candara", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(30, 131);
            label1.Name = "label1";
            label1.Size = new Size(139, 28);
            label1.TabIndex = 10;
            label1.Text = "ID Giỏ Hàng :";
            // 
            // txtIDGioHang
            // 
            txtIDGioHang.Location = new Point(243, 123);
            txtIDGioHang.Name = "txtIDGioHang";
            txtIDGioHang.Size = new Size(228, 36);
            txtIDGioHang.TabIndex = 9;
            // 
            // txtIDChiTietGioHang
            // 
            txtIDChiTietGioHang.Location = new Point(243, 57);
            txtIDChiTietGioHang.Name = "txtIDChiTietGioHang";
            txtIDChiTietGioHang.Size = new Size(228, 36);
            txtIDChiTietGioHang.TabIndex = 5;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Candara", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label3.Location = new Point(61, 201);
            label3.Name = "label3";
            label3.Size = new Size(111, 28);
            label3.TabIndex = 2;
            label3.Text = "Số lượng:";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Candara", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label2.Location = new Point(30, 65);
            label2.Name = "label2";
            label2.Size = new Size(207, 28);
            label2.TabIndex = 1;
            label2.Text = "ID Chi tiết giỏ hàng:";
            // 
            // btnXoa
            // 
            btnXoa.BackColor = SystemColors.ActiveCaption;
            btnXoa.Font = new Font("Candara", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnXoa.Location = new Point(393, 288);
            btnXoa.Name = "btnXoa";
            btnXoa.Size = new Size(150, 37);
            btnXoa.TabIndex = 30;
            btnXoa.Text = "Xóa";
            btnXoa.UseVisualStyleBackColor = false;
            btnXoa.Click += btnXoa_Click;
            // 
            // btnSua
            // 
            btnSua.BackColor = SystemColors.ActiveCaption;
            btnSua.Font = new Font("Candara", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnSua.Location = new Point(205, 288);
            btnSua.Name = "btnSua";
            btnSua.Size = new Size(144, 37);
            btnSua.TabIndex = 31;
            btnSua.Text = "Sửa";
            btnSua.UseVisualStyleBackColor = false;
            btnSua.Click += btnSua_Click;
            // 
            // btnThoat
            // 
            btnThoat.BackColor = SystemColors.ActiveCaption;
            btnThoat.Font = new Font("Candara", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnThoat.Location = new Point(755, 288);
            btnThoat.Name = "btnThoat";
            btnThoat.Size = new Size(150, 37);
            btnThoat.TabIndex = 33;
            btnThoat.Text = "Thoát";
            btnThoat.UseVisualStyleBackColor = false;
            btnThoat.Click += btnThoat_Click;
            // 
            // btnLamMoi
            // 
            btnLamMoi.BackColor = SystemColors.ActiveCaption;
            btnLamMoi.Font = new Font("Candara", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnLamMoi.Location = new Point(574, 288);
            btnLamMoi.Name = "btnLamMoi";
            btnLamMoi.Size = new Size(150, 37);
            btnLamMoi.TabIndex = 34;
            btnLamMoi.Text = "Làm mới";
            btnLamMoi.UseVisualStyleBackColor = false;
            btnLamMoi.Click += btnLamMoi_Click;
            // 
            // ChiCart
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1066, 600);
            Controls.Add(btnLamMoi);
            Controls.Add(btnThoat);
            Controls.Add(dtgvdal);
            Controls.Add(btnThem);
            Controls.Add(groupBox1);
            Controls.Add(btnXoa);
            Controls.Add(btnSua);
            Margin = new Padding(3, 4, 3, 4);
            Name = "ChiCart";
            Text = "ChiCart";
            Load += ChiCart_Load;
            ((System.ComponentModel.ISupportInitialize)dtgvdal).EndInit();
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private DataGridView dtgvdal;
        private Button btnThem;
        private GroupBox groupBox1;
        private Label label1;
        private TextBox txtIDGioHang;
        private TextBox txtIDChiTietGioHang;
        private Label label3;
        private Label label2;
        private Button btnXoa;
        private Button btnSua;
        private TextBox txtSoLuong;
        private Label label5;
        private TextBox txtGia;
        private Label label4;
        private TextBox txtIDSanPham;
        private Button btnThoat;
        private Button btnLamMoi;
    }
}