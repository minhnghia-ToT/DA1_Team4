﻿namespace GUI_Model
{
    partial class product
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(product));
            label1 = new Label();
            dtgvProd = new DataGridView();
            label2 = new Label();
            txtIDprod = new TextBox();
            txtname = new TextBox();
            label3 = new Label();
            txtprice = new TextBox();
            label4 = new Label();
            label5 = new Label();
            txtquantity = new TextBox();
            label6 = new Label();
            txtdescribe = new TextBox();
            label7 = new Label();
            txttimKiem = new TextBox();
            btnDong = new Button();
            btnXoa = new Button();
            btnSua = new Button();
            btnLuu = new Button();
            btnBoqua = new Button();
            btnBack = new Button();
            btnTimkiem = new Button();
            btnThem = new Button();
            btaddimg = new Button();
            pb1 = new PictureBox();
            ((System.ComponentModel.ISupportInitialize)dtgvProd).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pb1).BeginInit();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Sitka Banner", 36F, FontStyle.Italic, GraphicsUnit.Point, 163);
            label1.ForeColor = Color.Blue;
            label1.Location = new Point(580, 9);
            label1.Name = "label1";
            label1.Size = new Size(215, 87);
            label1.TabIndex = 4;
            label1.Text = "Product";
            label1.Click += label1_Click;
            // 
            // dtgvProd
            // 
            dtgvProd.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dtgvProd.BackgroundColor = SystemColors.ButtonHighlight;
            dtgvProd.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dtgvProd.Location = new Point(-1, 305);
            dtgvProd.Name = "dtgvProd";
            dtgvProd.RowHeadersWidth = 51;
            dtgvProd.Size = new Size(1334, 100);
            dtgvProd.TabIndex = 13;
            dtgvProd.CellContentClick += dataGridView1_CellContentClick;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("STXinwei", 12F, FontStyle.Bold, GraphicsUnit.Point, 134);
            label2.ForeColor = Color.Blue;
            label2.Location = new Point(31, 120);
            label2.Name = "label2";
            label2.Size = new Size(115, 21);
            label2.TabIndex = 14;
            label2.Text = "ID product";
            // 
            // txtIDprod
            // 
            txtIDprod.Location = new Point(168, 114);
            txtIDprod.Name = "txtIDprod";
            txtIDprod.Size = new Size(278, 27);
            txtIDprod.TabIndex = 15;
            // 
            // txtname
            // 
            txtname.Location = new Point(168, 147);
            txtname.Name = "txtname";
            txtname.Size = new Size(278, 27);
            txtname.TabIndex = 17;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("STXinwei", 12F, FontStyle.Bold, GraphicsUnit.Point, 134);
            label3.ForeColor = Color.Blue;
            label3.Location = new Point(485, 116);
            label3.Name = "label3";
            label3.Size = new Size(68, 21);
            label3.TabIndex = 16;
            label3.Text = "Image";
            // 
            // txtprice
            // 
            txtprice.Location = new Point(168, 245);
            txtprice.Name = "txtprice";
            txtprice.Size = new Size(278, 27);
            txtprice.TabIndex = 19;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("STXinwei", 12F, FontStyle.Bold, GraphicsUnit.Point, 134);
            label4.ForeColor = Color.Blue;
            label4.Location = new Point(90, 254);
            label4.Name = "label4";
            label4.Size = new Size(56, 21);
            label4.TabIndex = 18;
            label4.Text = "Price";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("STXinwei", 12F, FontStyle.Bold, GraphicsUnit.Point, 134);
            label5.ForeColor = Color.Blue;
            label5.Location = new Point(3, 153);
            label5.Name = "label5";
            label5.Size = new Size(149, 21);
            label5.TabIndex = 20;
            label5.Text = "Name product";
            // 
            // txtquantity
            // 
            txtquantity.Location = new Point(168, 211);
            txtquantity.Name = "txtquantity";
            txtquantity.Size = new Size(278, 27);
            txtquantity.TabIndex = 23;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("STXinwei", 12F, FontStyle.Bold, GraphicsUnit.Point, 134);
            label6.ForeColor = Color.Blue;
            label6.Location = new Point(61, 184);
            label6.Name = "label6";
            label6.Size = new Size(91, 21);
            label6.TabIndex = 22;
            label6.Text = "Describe";
            // 
            // txtdescribe
            // 
            txtdescribe.Location = new Point(168, 178);
            txtdescribe.Name = "txtdescribe";
            txtdescribe.Size = new Size(278, 27);
            txtdescribe.TabIndex = 25;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("STXinwei", 12F, FontStyle.Bold, GraphicsUnit.Point, 134);
            label7.ForeColor = Color.Blue;
            label7.Location = new Point(51, 217);
            label7.Name = "label7";
            label7.Size = new Size(96, 21);
            label7.TabIndex = 24;
            label7.Text = "Quantity";
            // 
            // txttimKiem
            // 
            txttimKiem.Anchor = AnchorStyles.Bottom;
            txttimKiem.BackColor = Color.LightGray;
            txttimKiem.Font = new Font("Microsoft Sans Serif", 10.2F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txttimKiem.Location = new Point(1030, 505);
            txttimKiem.Margin = new Padding(4, 5, 4, 5);
            txttimKiem.Name = "txttimKiem";
            txttimKiem.Size = new Size(256, 27);
            txttimKiem.TabIndex = 53;
            txttimKiem.Text = "Enter staff name...";
            // 
            // btnDong
            // 
            btnDong.Anchor = AnchorStyles.Bottom;
            btnDong.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnDong.ForeColor = Color.Black;
            btnDong.Image = (Image)resources.GetObject("btnDong.Image");
            btnDong.ImageAlign = ContentAlignment.MiddleLeft;
            btnDong.Location = new Point(684, 486);
            btnDong.Margin = new Padding(4, 5, 4, 5);
            btnDong.Name = "btnDong";
            btnDong.Size = new Size(101, 59);
            btnDong.TabIndex = 52;
            btnDong.Text = "Close";
            btnDong.UseVisualStyleBackColor = true;
            // 
            // btnXoa
            // 
            btnXoa.Anchor = AnchorStyles.Bottom;
            btnXoa.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnXoa.ForeColor = Color.Black;
            btnXoa.Image = (Image)resources.GetObject("btnXoa.Image");
            btnXoa.ImageAlign = ContentAlignment.MiddleLeft;
            btnXoa.Location = new Point(210, 486);
            btnXoa.Margin = new Padding(4, 5, 4, 5);
            btnXoa.Name = "btnXoa";
            btnXoa.Size = new Size(101, 59);
            btnXoa.TabIndex = 45;
            btnXoa.Text = "Delete";
            btnXoa.UseVisualStyleBackColor = true;
            // 
            // btnSua
            // 
            btnSua.Anchor = AnchorStyles.Bottom;
            btnSua.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnSua.ForeColor = Color.Black;
            btnSua.Image = (Image)resources.GetObject("btnSua.Image");
            btnSua.ImageAlign = ContentAlignment.MiddleLeft;
            btnSua.Location = new Point(335, 486);
            btnSua.Margin = new Padding(4, 5, 4, 5);
            btnSua.Name = "btnSua";
            btnSua.Size = new Size(101, 59);
            btnSua.TabIndex = 46;
            btnSua.Text = "Update";
            btnSua.UseVisualStyleBackColor = true;
            btnSua.Click += btnSua_Click;
            // 
            // btnLuu
            // 
            btnLuu.Anchor = AnchorStyles.Bottom;
            btnLuu.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnLuu.ForeColor = Color.Black;
            btnLuu.Image = (Image)resources.GetObject("btnLuu.Image");
            btnLuu.ImageAlign = ContentAlignment.MiddleLeft;
            btnLuu.Location = new Point(447, 486);
            btnLuu.Margin = new Padding(4, 5, 4, 5);
            btnLuu.Name = "btnLuu";
            btnLuu.Size = new Size(101, 59);
            btnLuu.TabIndex = 47;
            btnLuu.Text = "Save";
            btnLuu.UseVisualStyleBackColor = true;
            btnLuu.Click += btnLuu_Click;
            // 
            // btnBoqua
            // 
            btnBoqua.Anchor = AnchorStyles.Bottom;
            btnBoqua.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnBoqua.ForeColor = Color.Black;
            btnBoqua.Image = (Image)resources.GetObject("btnBoqua.Image");
            btnBoqua.ImageAlign = ContentAlignment.MiddleLeft;
            btnBoqua.Location = new Point(566, 486);
            btnBoqua.Margin = new Padding(4, 5, 4, 5);
            btnBoqua.Name = "btnBoqua";
            btnBoqua.Size = new Size(101, 59);
            btnBoqua.TabIndex = 48;
            btnBoqua.Text = "Refresh";
            btnBoqua.UseVisualStyleBackColor = true;
            // 
            // btnBack
            // 
            btnBack.Anchor = AnchorStyles.Bottom;
            btnBack.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnBack.ForeColor = Color.Black;
            btnBack.ImageAlign = ContentAlignment.MiddleLeft;
            btnBack.Location = new Point(807, 486);
            btnBack.Margin = new Padding(4, 5, 4, 5);
            btnBack.Name = "btnBack";
            btnBack.Size = new Size(101, 59);
            btnBack.TabIndex = 49;
            btnBack.Text = "Back";
            btnBack.UseVisualStyleBackColor = true;
            btnBack.Click += btnBack_Click;
            // 
            // btnTimkiem
            // 
            btnTimkiem.Anchor = AnchorStyles.Bottom;
            btnTimkiem.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnTimkiem.ForeColor = Color.Black;
            btnTimkiem.Image = (Image)resources.GetObject("btnTimkiem.Image");
            btnTimkiem.ImageAlign = ContentAlignment.MiddleLeft;
            btnTimkiem.Location = new Point(921, 486);
            btnTimkiem.Margin = new Padding(4, 5, 4, 5);
            btnTimkiem.Name = "btnTimkiem";
            btnTimkiem.Size = new Size(101, 59);
            btnTimkiem.TabIndex = 50;
            btnTimkiem.Text = "Search";
            btnTimkiem.UseVisualStyleBackColor = true;
            // 
            // btnThem
            // 
            btnThem.Anchor = AnchorStyles.Bottom;
            btnThem.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnThem.ForeColor = Color.Black;
            btnThem.Image = (Image)resources.GetObject("btnThem.Image");
            btnThem.ImageAlign = ContentAlignment.MiddleLeft;
            btnThem.Location = new Point(92, 486);
            btnThem.Margin = new Padding(4, 5, 4, 5);
            btnThem.Name = "btnThem";
            btnThem.Size = new Size(101, 59);
            btnThem.TabIndex = 44;
            btnThem.Text = "Add";
            btnThem.UseVisualStyleBackColor = true;
            btnThem.Click += btnThem_Click;
            // 
            // btaddimg
            // 
            btaddimg.FlatStyle = FlatStyle.Flat;
            btaddimg.Font = new Font("YouYuan", 10.8F, FontStyle.Bold, GraphicsUnit.Point, 134);
            btaddimg.ImageAlign = ContentAlignment.MiddleLeft;
            btaddimg.Location = new Point(485, 140);
            btaddimg.Name = "btaddimg";
            btaddimg.Size = new Size(111, 47);
            btaddimg.TabIndex = 54;
            btaddimg.Text = "Add IMG";
            btaddimg.TextAlign = ContentAlignment.MiddleRight;
            btaddimg.UseVisualStyleBackColor = true;
            btaddimg.Click += btaddimg_Click;
            // 
            // pb1
            // 
            pb1.BorderStyle = BorderStyle.FixedSingle;
            pb1.Location = new Point(648, 121);
            pb1.Name = "pb1";
            pb1.Padding = new Padding(3);
            pb1.Size = new Size(374, 154);
            pb1.SizeMode = PictureBoxSizeMode.Zoom;
            pb1.TabIndex = 55;
            pb1.TabStop = false;
            // 
            // product
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1333, 654);
            Controls.Add(pb1);
            Controls.Add(btaddimg);
            Controls.Add(txttimKiem);
            Controls.Add(btnDong);
            Controls.Add(btnXoa);
            Controls.Add(btnSua);
            Controls.Add(btnLuu);
            Controls.Add(btnBoqua);
            Controls.Add(btnBack);
            Controls.Add(btnTimkiem);
            Controls.Add(btnThem);
            Controls.Add(txtdescribe);
            Controls.Add(label7);
            Controls.Add(txtquantity);
            Controls.Add(label6);
            Controls.Add(label5);
            Controls.Add(txtprice);
            Controls.Add(label4);
            Controls.Add(txtname);
            Controls.Add(label3);
            Controls.Add(txtIDprod);
            Controls.Add(label2);
            Controls.Add(dtgvProd);
            Controls.Add(label1);
            Name = "product";
            Text = "Product ";
            Load += product_Load;
            ((System.ComponentModel.ISupportInitialize)dtgvProd).EndInit();
            ((System.ComponentModel.ISupportInitialize)pb1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private Label label1;
        private DataGridView dtgvProd;
        private Label label2;
        private TextBox txtIDprod;
        private TextBox txtname;
        private Label label3;
        private TextBox txtprice;
        private Label label4;
        private TextBox txtimg;
        private Label label5;
        private TextBox txtquantity;
        private Label label6;
        private TextBox txtdescribe;
        private Label label7;
        private TextBox txttimKiem;
        private Button btnDong;
        private Button btnXoa;
        private Button btnSua;
        private Button btnLuu;
        private Button btnBoqua;
        private Button btnBack;
        private Button btnTimkiem;
        private Button btnThem;
        private Button btaddimg;
        private PictureBox pb1;
    }
}