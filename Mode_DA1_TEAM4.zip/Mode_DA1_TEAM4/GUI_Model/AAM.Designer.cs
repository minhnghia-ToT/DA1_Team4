﻿namespace GUI_Model
{
    partial class AAM
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(AAM));
            txttimKiem = new TextBox();
            btnDong = new Button();
            btnXoa = new Button();
            btnSua = new Button();
            btnLuu = new Button();
            btnBoqua = new Button();
            btnDanhsach = new Button();
            btnBack = new Button();
            btnTimkiem = new Button();
            btnThem = new Button();
            dtgvStaff = new DataGridView();
            groupBox1 = new GroupBox();
            rbAdmin = new RadioButton();
            rbStaff = new RadioButton();
            txtPass = new TextBox();
            txtEmail = new TextBox();
            txtname = new TextBox();
            label5 = new Label();
            label4 = new Label();
            label3 = new Label();
            label2 = new Label();
            label1 = new Label();
            ((System.ComponentModel.ISupportInitialize)dtgvStaff).BeginInit();
            groupBox1.SuspendLayout();
            SuspendLayout();
            // 
            // txttimKiem
            // 
            txttimKiem.BackColor = Color.LightGray;
            txttimKiem.Font = new Font("Microsoft Sans Serif", 10.2F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txttimKiem.Location = new Point(1084, 463);
            txttimKiem.Margin = new Padding(4, 5, 4, 5);
            txttimKiem.Name = "txttimKiem";
            txttimKiem.Size = new Size(256, 27);
            txttimKiem.TabIndex = 63;
            txttimKiem.Text = "Enter staff name...";
            // 
            // btnDong
            // 
            btnDong.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnDong.ForeColor = Color.Black;
            btnDong.Image = (Image)resources.GetObject("btnDong.Image");
            btnDong.ImageAlign = ContentAlignment.MiddleLeft;
            btnDong.Location = new Point(738, 444);
            btnDong.Margin = new Padding(4, 5, 4, 5);
            btnDong.Name = "btnDong";
            btnDong.Size = new Size(101, 59);
            btnDong.TabIndex = 62;
            btnDong.Text = "Close";
            btnDong.UseVisualStyleBackColor = true;
            btnDong.Click += btnDong_Click;
            // 
            // btnXoa
            // 
            btnXoa.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnXoa.ForeColor = Color.Black;
            btnXoa.Image = (Image)resources.GetObject("btnXoa.Image");
            btnXoa.ImageAlign = ContentAlignment.MiddleLeft;
            btnXoa.Location = new Point(136, 444);
            btnXoa.Margin = new Padding(4, 5, 4, 5);
            btnXoa.Name = "btnXoa";
            btnXoa.Size = new Size(101, 59);
            btnXoa.TabIndex = 55;
            btnXoa.Text = "Delete";
            btnXoa.UseVisualStyleBackColor = true;
            btnXoa.Click += btnXoa_Click;
            // 
            // btnSua
            // 
            btnSua.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnSua.ForeColor = Color.Black;
            btnSua.Image = (Image)resources.GetObject("btnSua.Image");
            btnSua.ImageAlign = ContentAlignment.MiddleLeft;
            btnSua.Location = new Point(261, 444);
            btnSua.Margin = new Padding(4, 5, 4, 5);
            btnSua.Name = "btnSua";
            btnSua.Size = new Size(101, 59);
            btnSua.TabIndex = 56;
            btnSua.Text = "Update";
            btnSua.UseVisualStyleBackColor = true;
            btnSua.Click += btnSua_Click;
            // 
            // btnLuu
            // 
            btnLuu.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnLuu.ForeColor = Color.Black;
            btnLuu.Image = (Image)resources.GetObject("btnLuu.Image");
            btnLuu.ImageAlign = ContentAlignment.MiddleLeft;
            btnLuu.Location = new Point(373, 444);
            btnLuu.Margin = new Padding(4, 5, 4, 5);
            btnLuu.Name = "btnLuu";
            btnLuu.Size = new Size(101, 59);
            btnLuu.TabIndex = 57;
            btnLuu.Text = "Save";
            btnLuu.UseVisualStyleBackColor = true;
            btnLuu.Click += btnLuu_Click;
            // 
            // btnBoqua
            // 
            btnBoqua.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnBoqua.ForeColor = Color.Black;
            btnBoqua.Image = (Image)resources.GetObject("btnBoqua.Image");
            btnBoqua.ImageAlign = ContentAlignment.MiddleLeft;
            btnBoqua.Location = new Point(492, 444);
            btnBoqua.Margin = new Padding(4, 5, 4, 5);
            btnBoqua.Name = "btnBoqua";
            btnBoqua.Size = new Size(101, 59);
            btnBoqua.TabIndex = 58;
            btnBoqua.Text = "Refresh";
            btnBoqua.UseVisualStyleBackColor = true;
            btnBoqua.Click += btnBoqua_Click;
            // 
            // btnDanhsach
            // 
            btnDanhsach.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnDanhsach.ForeColor = Color.Black;
            btnDanhsach.Image = (Image)resources.GetObject("btnDanhsach.Image");
            btnDanhsach.ImageAlign = ContentAlignment.MiddleLeft;
            btnDanhsach.Location = new Point(612, 444);
            btnDanhsach.Margin = new Padding(4, 5, 4, 5);
            btnDanhsach.Name = "btnDanhsach";
            btnDanhsach.Size = new Size(101, 59);
            btnDanhsach.TabIndex = 61;
            btnDanhsach.Text = "List";
            btnDanhsach.UseVisualStyleBackColor = true;
            // 
            // btnBack
            // 
            btnBack.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnBack.ForeColor = Color.Black;
            btnBack.ImageAlign = ContentAlignment.MiddleLeft;
            btnBack.Location = new Point(861, 444);
            btnBack.Margin = new Padding(4, 5, 4, 5);
            btnBack.Name = "btnBack";
            btnBack.Size = new Size(101, 59);
            btnBack.TabIndex = 59;
            btnBack.Text = "Back";
            btnBack.UseVisualStyleBackColor = true;
            btnBack.Click += btnBack_Click;
            // 
            // btnTimkiem
            // 
            btnTimkiem.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnTimkiem.ForeColor = Color.Black;
            btnTimkiem.Image = (Image)resources.GetObject("btnTimkiem.Image");
            btnTimkiem.ImageAlign = ContentAlignment.MiddleLeft;
            btnTimkiem.Location = new Point(975, 444);
            btnTimkiem.Margin = new Padding(4, 5, 4, 5);
            btnTimkiem.Name = "btnTimkiem";
            btnTimkiem.Size = new Size(101, 59);
            btnTimkiem.TabIndex = 60;
            btnTimkiem.Text = "Search";
            btnTimkiem.UseVisualStyleBackColor = true;
            btnTimkiem.Click += btnTimkiem_Click;
            // 
            // btnThem
            // 
            btnThem.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnThem.ForeColor = Color.Black;
            btnThem.Image = (Image)resources.GetObject("btnThem.Image");
            btnThem.ImageAlign = ContentAlignment.MiddleLeft;
            btnThem.Location = new Point(18, 444);
            btnThem.Margin = new Padding(4, 5, 4, 5);
            btnThem.Name = "btnThem";
            btnThem.Size = new Size(101, 59);
            btnThem.TabIndex = 54;
            btnThem.Text = "Add";
            btnThem.UseVisualStyleBackColor = true;
            btnThem.Click += btnThem_Click;
            // 
            // dtgvStaff
            // 
            dtgvStaff.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dtgvStaff.GridColor = SystemColors.ActiveCaptionText;
            dtgvStaff.Location = new Point(18, 237);
            dtgvStaff.Name = "dtgvStaff";
            dtgvStaff.RowHeadersWidth = 51;
            dtgvStaff.Size = new Size(1323, 188);
            dtgvStaff.TabIndex = 53;
            dtgvStaff.Click += dtgvStaff_Click;
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(rbAdmin);
            groupBox1.Controls.Add(rbStaff);
            groupBox1.Location = new Point(261, 122);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(322, 88);
            groupBox1.TabIndex = 52;
            groupBox1.TabStop = false;
            // 
            // rbAdmin
            // 
            rbAdmin.AutoSize = true;
            rbAdmin.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
            rbAdmin.ForeColor = Color.Black;
            rbAdmin.Location = new Point(193, 27);
            rbAdmin.Name = "rbAdmin";
            rbAdmin.Size = new Size(95, 32);
            rbAdmin.TabIndex = 0;
            rbAdmin.TabStop = true;
            rbAdmin.Text = "Admin";
            rbAdmin.UseVisualStyleBackColor = true;
            // 
            // rbStaff
            // 
            rbStaff.AutoSize = true;
            rbStaff.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
            rbStaff.ForeColor = Color.Black;
            rbStaff.Location = new Point(39, 27);
            rbStaff.Name = "rbStaff";
            rbStaff.Size = new Size(79, 32);
            rbStaff.TabIndex = 0;
            rbStaff.TabStop = true;
            rbStaff.Text = "Staff";
            rbStaff.UseVisualStyleBackColor = true;
            // 
            // txtPass
            // 
            txtPass.Font = new Font("Arial", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            txtPass.Location = new Point(861, 145);
            txtPass.Name = "txtPass";
            txtPass.Size = new Size(322, 34);
            txtPass.TabIndex = 51;
            txtPass.TextChanged += txtPass_TextChanged;
            // 
            // txtEmail
            // 
            txtEmail.Font = new Font("Arial", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            txtEmail.Location = new Point(861, 72);
            txtEmail.Name = "txtEmail";
            txtEmail.Size = new Size(322, 34);
            txtEmail.TabIndex = 50;
            // 
            // txtname
            // 
            txtname.Font = new Font("Arial", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            txtname.Location = new Point(261, 70);
            txtname.Name = "txtname";
            txtname.Size = new Size(322, 34);
            txtname.TabIndex = 49;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label5.ForeColor = Color.DodgerBlue;
            label5.Location = new Point(706, 147);
            label5.Name = "label5";
            label5.Size = new Size(101, 28);
            label5.TabIndex = 47;
            label5.Text = "Password";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label4.ForeColor = Color.DodgerBlue;
            label4.Location = new Point(743, 72);
            label4.Name = "label4";
            label4.Size = new Size(64, 28);
            label4.TabIndex = 46;
            label4.Text = "Email";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label3.ForeColor = Color.DodgerBlue;
            label3.Location = new Point(172, 151);
            label3.Name = "label3";
            label3.Size = new Size(54, 28);
            label3.TabIndex = 45;
            label3.Text = "Role";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label2.ForeColor = Color.DodgerBlue;
            label2.Location = new Point(106, 72);
            label2.Name = "label2";
            label2.Size = new Size(136, 28);
            label2.TabIndex = 48;
            label2.Text = "Admin Name";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Arial", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.ForeColor = Color.DodgerBlue;
            label1.Location = new Point(501, 9);
            label1.Name = "label1";
            label1.Size = new Size(423, 35);
            label1.TabIndex = 44;
            label1.Text = "Admin Account Management";
            // 
            // AAM
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1357, 566);
            Controls.Add(txttimKiem);
            Controls.Add(btnDong);
            Controls.Add(btnXoa);
            Controls.Add(btnSua);
            Controls.Add(btnLuu);
            Controls.Add(btnBoqua);
            Controls.Add(btnDanhsach);
            Controls.Add(btnBack);
            Controls.Add(btnTimkiem);
            Controls.Add(btnThem);
            Controls.Add(dtgvStaff);
            Controls.Add(groupBox1);
            Controls.Add(txtPass);
            Controls.Add(txtEmail);
            Controls.Add(txtname);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Name = "AAM";
            Text = "Admin Account Management";
            Load += AAM_Load;
            ((System.ComponentModel.ISupportInitialize)dtgvStaff).EndInit();
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox txttimKiem;
        private Button btnDong;
        private Button btnXoa;
        private Button btnSua;
        private Button btnLuu;
        private Button btnBoqua;
        private Button btnDanhsach;
        private Button btnBack;
        private Button btnTimkiem;
        private Button btnThem;
        private DataGridView dtgvStaff;
        private GroupBox groupBox1;
        private RadioButton rbAdmin;
        private RadioButton rbStaff;
        private TextBox txtPass;
        private TextBox txtEmail;
        private TextBox txtname;
        private Label label5;
        private Label label4;
        private Label label3;
        private Label label2;
        private Label label1;
    }
}