﻿using BUS;
using DTO;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net.Mail;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace GUI_Model
{
    public partial class Form1 : Form
    {
        public string email { set; get; }
        public string pass { get; set; }

        BUS_Staff busstaff = new BUS_Staff();
        public Form1()
        {
            InitializeComponent();
        }
        private void button1_Click(object sender, EventArgs e)
        {
            DTO_Staff staff = new DTO_Staff();
            staff.EMAIL = txtEmail.Text;
            staff.Password = txtMK.Text;

            // Kiểm tra đăng nhập
            if (busstaff.StaffLogin(staff))
            {
                MessageBox.Show("Đăng nhập thành công");
                admin ad = new admin();
                ad.Show();
                this.Hide();
                //// Kiểm tra ID quyền
                //if (staff.IDQuyen == 1)
                //{
                //    MessageBox.Show("Đăng nhập thành công");
                //    admin ad = new admin();
                //    ad.Show();
                //    this.Hide();
                //}
                //else if(staff.IDQuyen == 2) 
                //{
                //    MessageBox.Show("Bạn không có quyền truy cập vào chức năng này!", "Lỗi");
                //    banhang bh = new banhang();
                //    bh.Show();
                //    this.Hide();

                //}
            }
            else
            {
                MessageBox.Show("Vui lòng kiểm tra lại Email và mật khẩu !");
                txtEmail.Focus();
            }
        }



        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            txtMK.PasswordChar = '*';
        }

        private void button2_Click(object sender, EventArgs e)
        {
            DTO_Staff staff = new DTO_Staff();
            staff.EMAIL = txtEmail.Text;
            staff.Password = txtMK.Text;
            // Kiểm tra đăng nhập
            if (busstaff.StaffLogin(staff))
            {
                // Kiểm tra ID quyền
                // Trong button2_Click
                if (staff.IDQuyen == 1)
                {
                    // ... Xử lý khi đăng nhập bằng tài khoản admin
                    MessageBox.Show("Bạn không có quyền truy cập vào chức năng này!", "Lỗi");
                    admin ad = new admin();
                    ad.Show();
                    this.Hide();
                }
                else if (staff.IDQuyen == 2)
                {
                    // ... Xử lý đăng nhập thành công cho nhân viên
                    MessageBox.Show("Đăng nhập thành công");
                    banhang bh = new banhang();
                    bh.Show();
                    this.Hide();
                }
                else
                {
                    MessageBox.Show("Bạn không có quyền truy cập vào chức năng này!", "Lỗi");
                }
            }
            else
            {
                MessageBox.Show("Vui lòng kiểm tra lại Email và mật khẩu !");
                txtEmail.Focus();
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Bạn có muốn thoát ứng dụng không?", "Xác nhận thoát", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (result == DialogResult.Yes)
            {
                Application.Exit();
            }
        }
    }
}
