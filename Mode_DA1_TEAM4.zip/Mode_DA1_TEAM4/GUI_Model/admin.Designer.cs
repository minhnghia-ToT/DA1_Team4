﻿namespace GUI_Model
{
    partial class admin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            menuStrip1 = new MenuStrip();
            quảnLýTàiKhoảnToolStripMenuItem = new ToolStripMenuItem();
            quảnLýSảnPhẩmToolStripMenuItem = new ToolStripMenuItem();
            warehouseManagementToolStripMenuItem = new ToolStripMenuItem();
            thốngKêToolStripMenuItem = new ToolStripMenuItem();
            backToolStripMenuItem = new ToolStripMenuItem();
            exitToolStripMenuItem = new ToolStripMenuItem();
            menuStrip1.SuspendLayout();
            SuspendLayout();
            // 
            // menuStrip1
            // 
            menuStrip1.BackColor = Color.LavenderBlush;
            menuStrip1.Dock = DockStyle.Bottom;
            menuStrip1.Font = new Font("Verdana", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 163);
            menuStrip1.ImageScalingSize = new Size(20, 20);
            menuStrip1.Items.AddRange(new ToolStripItem[] { quảnLýTàiKhoảnToolStripMenuItem, quảnLýSảnPhẩmToolStripMenuItem, warehouseManagementToolStripMenuItem, thốngKêToolStripMenuItem, backToolStripMenuItem, exitToolStripMenuItem });
            menuStrip1.Location = new Point(0, 649);
            menuStrip1.Margin = new Padding(50, 20, 20, 20);
            menuStrip1.MinimumSize = new Size(0, 100);
            menuStrip1.Name = "menuStrip1";
            menuStrip1.Padding = new Padding(260, 10, 0, 0);
            menuStrip1.RenderMode = ToolStripRenderMode.Professional;
            menuStrip1.Size = new Size(1783, 100);
            menuStrip1.TabIndex = 0;
            menuStrip1.Text = "menuStrip1";
            // 
            // quảnLýTàiKhoảnToolStripMenuItem
            // 
            quảnLýTàiKhoảnToolStripMenuItem.Image = Properties.Resources.acs;
            quảnLýTàiKhoảnToolStripMenuItem.Name = "quảnLýTàiKhoảnToolStripMenuItem";
            quảnLýTàiKhoảnToolStripMenuItem.Size = new Size(250, 90);
            quảnLýTàiKhoảnToolStripMenuItem.Text = "Account management";
            quảnLýTàiKhoảnToolStripMenuItem.Click += quảnLýTàiKhoảnToolStripMenuItem_Click;
            // 
            // quảnLýSảnPhẩmToolStripMenuItem
            // 
            quảnLýSảnPhẩmToolStripMenuItem.Image = Properties.Resources.features;
            quảnLýSảnPhẩmToolStripMenuItem.Name = "quảnLýSảnPhẩmToolStripMenuItem";
            quảnLýSảnPhẩmToolStripMenuItem.Size = new Size(245, 90);
            quảnLýSảnPhẩmToolStripMenuItem.Text = "Product Management";
            quảnLýSảnPhẩmToolStripMenuItem.Click += quảnLýSảnPhẩmToolStripMenuItem_Click;
            // 
            // warehouseManagementToolStripMenuItem
            // 
            warehouseManagementToolStripMenuItem.Image = Properties.Resources.material_management;
            warehouseManagementToolStripMenuItem.Name = "warehouseManagementToolStripMenuItem";
            warehouseManagementToolStripMenuItem.Size = new Size(277, 90);
            warehouseManagementToolStripMenuItem.Text = "Warehouse Management";
            warehouseManagementToolStripMenuItem.Click += warehouseManagementToolStripMenuItem_Click;
            // 
            // thốngKêToolStripMenuItem
            // 
            thốngKêToolStripMenuItem.Image = Properties.Resources.warehouse;
            thốngKêToolStripMenuItem.Name = "thốngKêToolStripMenuItem";
            thốngKêToolStripMenuItem.Size = new Size(139, 90);
            thốngKêToolStripMenuItem.Text = "Statistical";
            thốngKêToolStripMenuItem.Click += thốngKêToolStripMenuItem_Click;
            // 
            // backToolStripMenuItem
            // 
            backToolStripMenuItem.Image = Properties.Resources.back;
            backToolStripMenuItem.Name = "backToolStripMenuItem";
            backToolStripMenuItem.Size = new Size(94, 90);
            backToolStripMenuItem.Text = "Back ";
            backToolStripMenuItem.Click += backToolStripMenuItem_Click;
            // 
            // exitToolStripMenuItem
            // 
            exitToolStripMenuItem.Image = Properties.Resources.out1;
            exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            exitToolStripMenuItem.Size = new Size(80, 90);
            exitToolStripMenuItem.Text = "Exit";
            exitToolStripMenuItem.Click += exitToolStripMenuItem_Click;
            // 
            // admin
            // 
            AutoScaleMode = AutoScaleMode.None;
            BackColor = Color.White;
            BackgroundImage = Properties.Resources.Thêm_tiêu_đề1;
            ClientSize = new Size(1783, 749);
            Controls.Add(menuStrip1);
            ImeMode = ImeMode.On;
            MainMenuStrip = menuStrip1;
            Name = "admin";
            Text = "Management";
            Load += admin_Load;
            menuStrip1.ResumeLayout(false);
            menuStrip1.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private MenuStrip menuStrip1;
        private ToolStripMenuItem quảnLýTàiKhoảnToolStripMenuItem;
        private ToolStripMenuItem quảnLýSảnPhẩmToolStripMenuItem;
        private ToolStripMenuItem thốngKêToolStripMenuItem;
        private ToolStripMenuItem backToolStripMenuItem;
        private ToolStripMenuItem exitToolStripMenuItem;
        private ToolStripMenuItem warehouseManagementToolStripMenuItem;
    }
}