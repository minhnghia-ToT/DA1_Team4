﻿using DAL;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GUI_Model
{
    public partial class ChiCart : Form
    {
        private DAL_ChiCart dal;
        private string connectionString = @"Data Source=NhatAnhne;Initial Catalog=ZXC;Persist Security Info=True;User ID=sa;Password=***********;Integrated Security=True;";

        public ChiCart()
        {
            InitializeComponent();
            dal = new DAL_ChiCart(connectionString);
            LoadGridview();
        }

        private void ChiCart_Load(object sender, EventArgs e)
        {
            LoadGridview();
        }

        private void LoadGridview()
        {
            try
            {
                int idGioHang = 1; // You may want to change this or get it from a control
                DataTable dt = dal.GetChiTietGioHangIDGioHang(idGioHang);

                dtgvdal.DataSource = dt;
                dtgvdal.Columns[0].HeaderText = "IDChiTietGioHang";
                dtgvdal.Columns[1].HeaderText = "IDGioHang";
                dtgvdal.Columns[2].HeaderText = "IDSanPham";
                dtgvdal.Columns[3].HeaderText = "SoLuong";
                dtgvdal.Columns[4].HeaderText = "Gia";
            }
            catch (Exception ex)
            {
                MessageBox.Show("Load data failed: " + ex.Message);
            }
        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void dtgvdal_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void btnThem_Click(object sender, EventArgs e)
        {
            try
            {
                int idGioHang = int.Parse(txtIDGioHang.Text);
                int idSanPham = int.Parse(txtIDSanPham.Text);
                int soLuong = int.Parse(txtSoLuong.Text);
                decimal gia = decimal.Parse(txtGia.Text);
                dal.Insert_ChiTietGioHang(idGioHang, idSanPham, soLuong, gia);
                MessageBox.Show("Insert successful");
                LoadGridview();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Insert failed: " + ex.Message);
            }
        }

        private void btnSua_Click(object sender, EventArgs e)
        {
            try
            {
                int idChiTietGioHang = int.Parse(txtIDChiTietGioHang.Text);
                int soLuong = int.Parse(txtSoLuong.Text);
                decimal gia = decimal.Parse(txtGia.Text);
                dal.Update_ChiTietGioHang(idChiTietGioHang, soLuong, gia);
                MessageBox.Show("Update successful");
                LoadGridview();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Update failed: " + ex.Message);
            }
        }

        private void btnXoa_Click(object sender, EventArgs e)
        {
            try
            {
                int idChiTietGioHang = int.Parse(txtIDChiTietGioHang.Text);
                dal.Delete_ChiTietGioHang(idChiTietGioHang);
                MessageBox.Show("Delete successful");
                LoadGridview();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Delete failed: " + ex.Message);
            }
        }

        private void btnThoat_Click(object sender, EventArgs e)
        {
            Cart Cart = new Cart();
            Cart.Show();
            this.Close();
        }

        private void btnLamMoi_Click(object sender, EventArgs e)
        {
            ChiCart chicart = new ChiCart();
            chicart.Show();
            this.Hide();
        }
    }
}
