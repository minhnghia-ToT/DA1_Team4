﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using DAL;



namespace GUI_Model
{
    public partial class Cart : Form
    {
        private DAL_Cart dal;
        private string connectionString = @"Data Source=NhatAnhne;Initial Catalog=ZXC;Persist Security Info=True;User ID=sa;Password=***********;Integrated Security=True;";
        public Cart()
        {
            InitializeComponent();
            dal = new DAL_Cart(connectionString);
            LoadGridview();
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }


        private void Cart_Load(object sender, EventArgs e)
        {
            LoadGridview();
        }
        private void LoadGridview()
        {
            try
            {
                DataTable dt = dal.GetGioHang();
                dtgvdal.DataSource = dt;
                dtgvdal.Columns[0].HeaderText = "IDGioHang";
                dtgvdal.Columns[1].HeaderText = "IDNhanVien";
                dtgvdal.Columns[2].HeaderText = "NgayTao";
            }
            catch (Exception ex)
            {
                MessageBox.Show("Load data failed: " + ex.Message);
            }
        }


        private void btnThem_Click(object sender, EventArgs e)
        {
            try
            {
                int idNhanVien = int.Parse(txtIDNhanVien.Text);
                DateTime ngayTao = dateTimePickerNgayTao.Value;
                dal.Insert_GioHang(idNhanVien, ngayTao);
                MessageBox.Show("Insert successful");
                LoadGridview();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Insert failed: " + ex.Message);
            }
        }

        private void btnSua_Click_1(object sender, EventArgs e)
        {
            try
            {
                int idGioHang = int.Parse(txtIDGioHang.Text);
                int idNhanVien = int.Parse(txtIDNhanVien.Text);
                DateTime ngayTao = dateTimePickerNgayTao.Value;
                dal.Update_GioHang(idGioHang, idNhanVien, ngayTao);
                MessageBox.Show("Update successful");
                LoadGridview();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Update failed: " + ex.Message);
            }
        }

        private void btnXoa_Click_1(object sender, EventArgs e)
        {
            try
            {
                if (int.TryParse(txtIDGioHang.Text, out int idGioHang))
                {
                    dal.Delete_GioHang(idGioHang);
                    MessageBox.Show("Delete successful");
                    LoadGridview();
                }
                else
                {
                    MessageBox.Show("Please enter a valid IDGioHang");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Delete failed: " + ex.Message);
            }
        }

        private void btnThoat_Click_1(object sender, EventArgs e)
        {
            banhang bh = new banhang();
            bh.Show();
            this.Close();
        }

        private void dtgvdal_CellContentClick_1(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void txtIDNhanVien_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnChiTietGioHang_Click(object sender, EventArgs e)
        {
            ChiCart chicart = new ChiCart();
            chicart.Show();
            this.Hide();
        }

        private void btnLamMoi_Click(object sender, EventArgs e)
        {
            Cart cart = new Cart();
            cart.Show();
            this.Hide();
        }

        private void Cart_Load_1(object sender, EventArgs e)
        {

        }
    }
}

