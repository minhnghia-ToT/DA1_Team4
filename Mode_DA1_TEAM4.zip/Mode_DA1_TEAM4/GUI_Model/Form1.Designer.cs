﻿namespace GUI_Model
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            pictureBox1 = new PictureBox();
            btn_ad = new Button();
            label1 = new Label();
            pictureBox2 = new PictureBox();
            panel1 = new Panel();
            panel2 = new Panel();
            panel3 = new Panel();
            panel4 = new Panel();
            panel5 = new Panel();
            panel6 = new Panel();
            pictureBox3 = new PictureBox();
            txtEmail = new TextBox();
            txtMK = new TextBox();
            btn_staff = new Button();
            btn_logout = new Button();
            bunifuBarChart1 = new Bunifu.Charts.WinForms.ChartTypes.BunifuBarChart(components);
            bunifuBarChart2 = new Bunifu.Charts.WinForms.ChartTypes.BunifuBarChart(components);
            bunifuLineChart1 = new Bunifu.Charts.WinForms.ChartTypes.BunifuLineChart(components);
            bunifuPolarAreaChart1 = new Bunifu.Charts.WinForms.ChartTypes.BunifuPolarAreaChart(components);
            bunifuRadarChart1 = new Bunifu.Charts.WinForms.ChartTypes.BunifuRadarChart(components);
            bunifuRadarChart2 = new Bunifu.Charts.WinForms.ChartTypes.BunifuRadarChart(components);
            bunifuPolarAreaChart2 = new Bunifu.Charts.WinForms.ChartTypes.BunifuPolarAreaChart(components);
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).BeginInit();
            SuspendLayout();
            // 
            // pictureBox1
            // 
            pictureBox1.BorderStyle = BorderStyle.FixedSingle;
            pictureBox1.Image = Properties.Resources.loginnew;
            pictureBox1.Location = new Point(127, 38);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(170, 96);
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox1.TabIndex = 0;
            pictureBox1.TabStop = false;
            // 
            // btn_ad
            // 
            btn_ad.BackColor = Color.Firebrick;
            btn_ad.Cursor = Cursors.Hand;
            btn_ad.FlatStyle = FlatStyle.Flat;
            btn_ad.Font = new Font("Microsoft Sans Serif", 13.7999992F, FontStyle.Bold, GraphicsUnit.Point, 134);
            btn_ad.ForeColor = Color.NavajoWhite;
            btn_ad.Image = Properties.Resources.people;
            btn_ad.ImageAlign = ContentAlignment.TopCenter;
            btn_ad.Location = new Point(19, 423);
            btn_ad.Name = "btn_ad";
            btn_ad.Size = new Size(122, 165);
            btn_ad.TabIndex = 0;
            btn_ad.Text = "  Admin ";
            btn_ad.UseVisualStyleBackColor = false;
            btn_ad.Click += button1_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Bauhaus 93", 24F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.ForeColor = Color.FromArgb(0, 117, 124);
            label1.Location = new Point(148, 137);
            label1.Name = "label1";
            label1.Size = new Size(130, 45);
            label1.TabIndex = 4;
            label1.Text = "LOGIN";
            // 
            // pictureBox2
            // 
            pictureBox2.Image = Properties.Resources.user;
            pictureBox2.Location = new Point(63, 235);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(25, 25);
            pictureBox2.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox2.TabIndex = 5;
            pictureBox2.TabStop = false;
            // 
            // panel1
            // 
            panel1.Location = new Point(88, 259);
            panel1.Name = "panel1";
            panel1.Size = new Size(236, 1);
            panel1.TabIndex = 6;
            // 
            // panel2
            // 
            panel2.Location = new Point(88, 259);
            panel2.Name = "panel2";
            panel2.Size = new Size(236, 1);
            panel2.TabIndex = 7;
            // 
            // panel3
            // 
            panel3.BackColor = Color.FromArgb(0, 117, 214);
            panel3.Location = new Point(63, 266);
            panel3.Name = "panel3";
            panel3.Size = new Size(300, 1);
            panel3.TabIndex = 8;
            // 
            // panel4
            // 
            panel4.BackColor = Color.FromArgb(0, 117, 214);
            panel4.Location = new Point(63, 338);
            panel4.Name = "panel4";
            panel4.Size = new Size(300, 1);
            panel4.TabIndex = 12;
            // 
            // panel5
            // 
            panel5.Location = new Point(88, 331);
            panel5.Name = "panel5";
            panel5.Size = new Size(236, 1);
            panel5.TabIndex = 11;
            // 
            // panel6
            // 
            panel6.Location = new Point(88, 331);
            panel6.Name = "panel6";
            panel6.Size = new Size(236, 1);
            panel6.TabIndex = 10;
            // 
            // pictureBox3
            // 
            pictureBox3.Image = Properties.Resources.padlock;
            pictureBox3.Location = new Point(56, 307);
            pictureBox3.Name = "pictureBox3";
            pictureBox3.Size = new Size(36, 29);
            pictureBox3.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox3.TabIndex = 9;
            pictureBox3.TabStop = false;
            // 
            // txtEmail
            // 
            txtEmail.BackColor = SystemColors.HighlightText;
            txtEmail.BorderStyle = BorderStyle.None;
            txtEmail.Font = new Font("Microsoft Sans Serif", 10.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            txtEmail.ForeColor = Color.FromArgb(0, 117, 214);
            txtEmail.Location = new Point(94, 239);
            txtEmail.Multiline = true;
            txtEmail.Name = "txtEmail";
            txtEmail.Size = new Size(267, 24);
            txtEmail.TabIndex = 13;
            // 
            // txtMK
            // 
            txtMK.BackColor = SystemColors.HighlightText;
            txtMK.BorderStyle = BorderStyle.None;
            txtMK.Font = new Font("Microsoft Sans Serif", 10.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            txtMK.ForeColor = Color.FromArgb(0, 117, 214);
            txtMK.Location = new Point(96, 312);
            txtMK.Multiline = true;
            txtMK.Name = "txtMK";
            txtMK.Size = new Size(267, 24);
            txtMK.TabIndex = 14;
            txtMK.TextChanged += textBox2_TextChanged;
            // 
            // btn_staff
            // 
            btn_staff.BackColor = Color.Peru;
            btn_staff.Cursor = Cursors.Hand;
            btn_staff.FlatStyle = FlatStyle.Flat;
            btn_staff.Font = new Font("Microsoft Sans Serif", 13.7999992F, FontStyle.Bold, GraphicsUnit.Point, 134);
            btn_staff.ForeColor = Color.NavajoWhite;
            btn_staff.Image = Properties.Resources.cleaning_staff;
            btn_staff.ImageAlign = ContentAlignment.TopCenter;
            btn_staff.Location = new Point(152, 423);
            btn_staff.Name = "btn_staff";
            btn_staff.Size = new Size(122, 165);
            btn_staff.TabIndex = 15;
            btn_staff.Text = "Staff";
            btn_staff.UseVisualStyleBackColor = false;
            btn_staff.Click += button2_Click;
            // 
            // btn_logout
            // 
            btn_logout.BackColor = Color.Tomato;
            btn_logout.Cursor = Cursors.Hand;
            btn_logout.FlatStyle = FlatStyle.Flat;
            btn_logout.Font = new Font("Microsoft Sans Serif", 13.7999992F, FontStyle.Bold, GraphicsUnit.Point, 134);
            btn_logout.ForeColor = Color.Moccasin;
            btn_logout.Image = Properties.Resources.arrow;
            btn_logout.ImageAlign = ContentAlignment.TopCenter;
            btn_logout.Location = new Point(288, 423);
            btn_logout.Name = "btn_logout";
            btn_logout.Size = new Size(122, 165);
            btn_logout.TabIndex = 16;
            btn_logout.Text = "Logout";
            btn_logout.UseVisualStyleBackColor = false;
            btn_logout.Click += button3_Click;
            // 
            // bunifuBarChart1
            // 
            bunifuBarChart1.BackgroundColor = (List<Color>)resources.GetObject("bunifuBarChart1.BackgroundColor");
            bunifuBarChart1.BorderColor = (List<Color>)resources.GetObject("bunifuBarChart1.BorderColor");
            bunifuBarChart1.BorderSkipped = null;
            bunifuBarChart1.BorderWidth = 0;
            bunifuBarChart1.Data = (List<double>)resources.GetObject("bunifuBarChart1.Data");
            bunifuBarChart1.HoverBackgroundColor = Color.Empty;
            bunifuBarChart1.HoverBorderColor = Color.Empty;
            bunifuBarChart1.HoverBorderWidth = 0;
            bunifuBarChart1.Label = "Label here";
            bunifuBarChart1.TargetCanvas = null;
            // 
            // bunifuBarChart2
            // 
            bunifuBarChart2.BackgroundColor = (List<Color>)resources.GetObject("bunifuBarChart2.BackgroundColor");
            bunifuBarChart2.BorderColor = (List<Color>)resources.GetObject("bunifuBarChart2.BorderColor");
            bunifuBarChart2.BorderSkipped = null;
            bunifuBarChart2.BorderWidth = 0;
            bunifuBarChart2.Data = (List<double>)resources.GetObject("bunifuBarChart2.Data");
            bunifuBarChart2.HoverBackgroundColor = Color.Empty;
            bunifuBarChart2.HoverBorderColor = Color.Empty;
            bunifuBarChart2.HoverBorderWidth = 0;
            bunifuBarChart2.Label = "Label here";
            bunifuBarChart2.TargetCanvas = null;
            // 
            // bunifuLineChart1
            // 
            bunifuLineChart1.BackgroundColor = Color.Indigo;
            bunifuLineChart1.BorderCapStyle = Bunifu.Charts.WinForms.ChartTypes.BunifuLineChart.LineCaps.Butt;
            bunifuLineChart1.BorderColor = Color.Purple;
            bunifuLineChart1.BorderDash = null;
            bunifuLineChart1.BorderDashOffset = 0D;
            bunifuLineChart1.BorderJoin = Bunifu.Charts.WinForms.ChartTypes.BunifuLineChart.BorderJoinStyles.Miter;
            bunifuLineChart1.BorderWidth = 3;
            bunifuLineChart1.CubicInterpolationMode = Bunifu.Charts.WinForms.ChartTypes.BunifuLineChart.CubicInterpolationModes.Default;
            bunifuLineChart1.Data = (List<double>)resources.GetObject("bunifuLineChart1.Data");
            bunifuLineChart1.Fill = Bunifu.Charts.WinForms.ChartTypes.BunifuLineChart.FillOptions.Blank;
            bunifuLineChart1.Label = "Line Chart";
            bunifuLineChart1.LineTension = 0.4D;
            bunifuLineChart1.Order = 0;
            bunifuLineChart1.PointBackgroundColor = Color.Empty;
            bunifuLineChart1.PointBorderColor = Color.Empty;
            bunifuLineChart1.PointBorderWidth = 1;
            bunifuLineChart1.PointHitRadius = 1;
            bunifuLineChart1.PointHoverBackgroundColor = Color.Empty;
            bunifuLineChart1.PointHoverBorderColor = Color.Empty;
            bunifuLineChart1.PointHoverBorderWidth = 4;
            bunifuLineChart1.PointHoverRadius = 1;
            bunifuLineChart1.PointRadius = 3;
            bunifuLineChart1.PointRotation = 0;
            bunifuLineChart1.PointStyle = Bunifu.Charts.WinForms.ChartTypes.BunifuLineChart.PointStyles.Circle;
            bunifuLineChart1.ShowLine = true;
            bunifuLineChart1.SpanGaps = false;
            bunifuLineChart1.SteppedLine = Bunifu.Charts.WinForms.ChartTypes.BunifuLineChart.SteppedLineStyles.False;
            bunifuLineChart1.TargetCanvas = null;
            // 
            // bunifuPolarAreaChart1
            // 
            bunifuPolarAreaChart1.BackgroundColor = (List<Color>)resources.GetObject("bunifuPolarAreaChart1.BackgroundColor");
            bunifuPolarAreaChart1.BorderAlign = Bunifu.Charts.WinForms.ChartTypes.BunifuPolarAreaChart.BorderAlignmentOptions.Centre;
            bunifuPolarAreaChart1.BorderColor = (List<Color>)resources.GetObject("bunifuPolarAreaChart1.BorderColor");
            bunifuPolarAreaChart1.BorderWidth = 0;
            bunifuPolarAreaChart1.Data = (List<double>)resources.GetObject("bunifuPolarAreaChart1.Data");
            bunifuPolarAreaChart1.HoverBackgroundColor = Color.Empty;
            bunifuPolarAreaChart1.HoverBorderColor = Color.Empty;
            bunifuPolarAreaChart1.HoverBorderWidth = 0;
            bunifuPolarAreaChart1.Label = "Label here";
            bunifuPolarAreaChart1.TargetCanvas = null;
            // 
            // bunifuRadarChart1
            // 
            bunifuRadarChart1.BackgroundColor = Color.Indigo;
            bunifuRadarChart1.BorderCapStyle = Bunifu.Charts.WinForms.ChartTypes.BunifuRadarChart.LineCaps.Butt;
            bunifuRadarChart1.BorderColor = Color.Purple;
            bunifuRadarChart1.BorderDash = null;
            bunifuRadarChart1.BorderDashOffset = 0D;
            bunifuRadarChart1.BorderJoin = Bunifu.Charts.WinForms.ChartTypes.BunifuRadarChart.BorderJoinStyles.Miter;
            bunifuRadarChart1.BorderWidth = 3;
            bunifuRadarChart1.CubicInterpolationMode = Bunifu.Charts.WinForms.ChartTypes.BunifuRadarChart.CubicInterpolationModes.Default;
            bunifuRadarChart1.Data = (List<double>)resources.GetObject("bunifuRadarChart1.Data");
            bunifuRadarChart1.Fill = "false";
            bunifuRadarChart1.Label = "Line Chart";
            bunifuRadarChart1.LineTension = 0.4D;
            bunifuRadarChart1.Order = 0;
            bunifuRadarChart1.PointBackgroundColor = Color.Empty;
            bunifuRadarChart1.PointBorderColor = Color.Empty;
            bunifuRadarChart1.PointBorderWidth = 1;
            bunifuRadarChart1.PointHitRadius = 1;
            bunifuRadarChart1.PointHoverBackgroundColor = Color.Empty;
            bunifuRadarChart1.PointHoverBorderColor = Color.Empty;
            bunifuRadarChart1.PointHoverBorderWidth = 4;
            bunifuRadarChart1.PointHoverRadius = 1;
            bunifuRadarChart1.PointRadius = 3;
            bunifuRadarChart1.PointRotation = 0;
            bunifuRadarChart1.PointStyle = Bunifu.Charts.WinForms.ChartTypes.BunifuRadarChart.PointStyles.Circle;
            bunifuRadarChart1.ShowLine = true;
            bunifuRadarChart1.SpanGaps = false;
            bunifuRadarChart1.SteppedLine = Bunifu.Charts.WinForms.ChartTypes.BunifuRadarChart.SteppedLineStyles.False;
            bunifuRadarChart1.TargetCanvas = null;
            // 
            // bunifuRadarChart2
            // 
            bunifuRadarChart2.BackgroundColor = Color.Indigo;
            bunifuRadarChart2.BorderCapStyle = Bunifu.Charts.WinForms.ChartTypes.BunifuRadarChart.LineCaps.Butt;
            bunifuRadarChart2.BorderColor = Color.Purple;
            bunifuRadarChart2.BorderDash = null;
            bunifuRadarChart2.BorderDashOffset = 0D;
            bunifuRadarChart2.BorderJoin = Bunifu.Charts.WinForms.ChartTypes.BunifuRadarChart.BorderJoinStyles.Miter;
            bunifuRadarChart2.BorderWidth = 3;
            bunifuRadarChart2.CubicInterpolationMode = Bunifu.Charts.WinForms.ChartTypes.BunifuRadarChart.CubicInterpolationModes.Default;
            bunifuRadarChart2.Data = (List<double>)resources.GetObject("bunifuRadarChart2.Data");
            bunifuRadarChart2.Fill = "false";
            bunifuRadarChart2.Label = "Line Chart";
            bunifuRadarChart2.LineTension = 0.4D;
            bunifuRadarChart2.Order = 0;
            bunifuRadarChart2.PointBackgroundColor = Color.Empty;
            bunifuRadarChart2.PointBorderColor = Color.Empty;
            bunifuRadarChart2.PointBorderWidth = 1;
            bunifuRadarChart2.PointHitRadius = 1;
            bunifuRadarChart2.PointHoverBackgroundColor = Color.Empty;
            bunifuRadarChart2.PointHoverBorderColor = Color.Empty;
            bunifuRadarChart2.PointHoverBorderWidth = 4;
            bunifuRadarChart2.PointHoverRadius = 1;
            bunifuRadarChart2.PointRadius = 3;
            bunifuRadarChart2.PointRotation = 0;
            bunifuRadarChart2.PointStyle = Bunifu.Charts.WinForms.ChartTypes.BunifuRadarChart.PointStyles.Circle;
            bunifuRadarChart2.ShowLine = true;
            bunifuRadarChart2.SpanGaps = false;
            bunifuRadarChart2.SteppedLine = Bunifu.Charts.WinForms.ChartTypes.BunifuRadarChart.SteppedLineStyles.False;
            bunifuRadarChart2.TargetCanvas = null;
            // 
            // bunifuPolarAreaChart2
            // 
            bunifuPolarAreaChart2.BackgroundColor = (List<Color>)resources.GetObject("bunifuPolarAreaChart2.BackgroundColor");
            bunifuPolarAreaChart2.BorderAlign = Bunifu.Charts.WinForms.ChartTypes.BunifuPolarAreaChart.BorderAlignmentOptions.Centre;
            bunifuPolarAreaChart2.BorderColor = (List<Color>)resources.GetObject("bunifuPolarAreaChart2.BorderColor");
            bunifuPolarAreaChart2.BorderWidth = 0;
            bunifuPolarAreaChart2.Data = (List<double>)resources.GetObject("bunifuPolarAreaChart2.Data");
            bunifuPolarAreaChart2.HoverBackgroundColor = Color.Empty;
            bunifuPolarAreaChart2.HoverBorderColor = Color.Empty;
            bunifuPolarAreaChart2.HoverBorderWidth = 0;
            bunifuPolarAreaChart2.Label = "Label here";
            bunifuPolarAreaChart2.TargetCanvas = null;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(437, 599);
            Controls.Add(btn_logout);
            Controls.Add(btn_staff);
            Controls.Add(txtMK);
            Controls.Add(txtEmail);
            Controls.Add(panel4);
            Controls.Add(panel5);
            Controls.Add(panel3);
            Controls.Add(panel6);
            Controls.Add(panel2);
            Controls.Add(pictureBox3);
            Controls.Add(panel1);
            Controls.Add(pictureBox2);
            Controls.Add(label1);
            Controls.Add(btn_ad);
            Controls.Add(pictureBox1);
            Name = "Form1";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Login";
            Load += Form1_Load;
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private PictureBox pictureBox1;
        private Button btn_ad;
        private Label label1;
        private PictureBox pictureBox2;
        private Panel panel1;
        private Panel panel2;
        private Panel panel3;
        private Panel panel4;
        private Panel panel5;
        private Panel panel6;
        private PictureBox pictureBox3;
        private TextBox txtEmail;
        private TextBox txtMK;
        private Button btn_staff;
        private Button btn_logout;
        private Bunifu.Charts.WinForms.ChartTypes.BunifuBarChart bunifuBarChart1;
        private Bunifu.Charts.WinForms.ChartTypes.BunifuBarChart bunifuBarChart2;
        private Bunifu.Charts.WinForms.ChartTypes.BunifuLineChart bunifuLineChart1;
        private Bunifu.Charts.WinForms.ChartTypes.BunifuPolarAreaChart bunifuPolarAreaChart1;
        private Bunifu.Charts.WinForms.ChartTypes.BunifuRadarChart bunifuRadarChart1;
        private Bunifu.Charts.WinForms.ChartTypes.BunifuRadarChart bunifuRadarChart2;
        private Bunifu.Charts.WinForms.ChartTypes.BunifuPolarAreaChart bunifuPolarAreaChart2;
    }
}
