﻿using BUS;
using DTO;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net.Mail;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ListView;

namespace GUI_Model
{
    public partial class TrendingProd : Form
    {
        BUS_TrendingProd trend = new BUS_TrendingProd();
        public TrendingProd()
        {
            InitializeComponent();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            banhang bh = new banhang();
            bh.Show();
            this.Close();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
        private void LoadGridview()
        {
            var dataSource = trend.getTopSP();
            if (dataSource != null && dataSource.Rows.Count > 0)
            {
                dtgv.DataSource = dataSource;

                // Debugging: Check the number of columns and their names
                int columnCount = dataSource.Columns.Count;
                StringBuilder columnNames = new StringBuilder();
                foreach (DataColumn column in dataSource.Columns)
                {
                    columnNames.AppendLine(column.ColumnName);
                }
           

                if (columnCount >= 5)
                {
                    dtgv.Columns[0].HeaderText = "ID";
                    dtgv.Columns[1].HeaderText = "Name";
                    dtgv.Columns[2].HeaderText = "Describe";
                    dtgv.Columns[3].HeaderText = "Price";
                    dtgv.Columns[4].HeaderText = "Quantity";
                }
                else
                {
                    MessageBox.Show("The data source does not have the expected number of columns.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            else
            {
                MessageBox.Show("No data available to display.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }







        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void TrendingProd_Load(object sender, EventArgs e)
        {
            LoadGridview();
        }
    }
}
