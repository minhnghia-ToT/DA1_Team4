﻿using BUS;
using DTO;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GUI_Model
{
    public partial class warehouse : Form
    {
        BUS_wareH wareH = new BUS_wareH();
        public warehouse()
        {
            InitializeComponent();
            LoadGridview();
        }

        private void warehouse_Load(object sender, EventArgs e)
        {

        }

        private void button6_Click(object sender, EventArgs e)
        {
            admin ad = new admin();
            ad.Show();
            this.Close();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void dtvg_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void LoadGridview()
        {
            dtvg.DataSource = wareH.GetKhoData();
            dtvg.Columns[0].HeaderText = "IDpro";
            dtvg.Columns[1].HeaderText = "IDware";
            dtvg.Columns[2].HeaderText = "Dayadded";
            dtvg.Columns[3].HeaderText = "Exporttdate";
            dtvg.Columns[4].HeaderText = "Quantity";
            dtvg.Columns[5].HeaderText = "Importprice";
            dtvg.Columns[6].HeaderText = "Exportprice";

        }

        private void bttn_Click(object sender, EventArgs e)
        {
            string IDsanpham = txttimkiem.Text;// tìm theo tên
            DataTable ds = wareH.seach_Kho(IDsanpham);
            if (ds.Rows.Count > 0) // tìm thấy kết quả => load lên
            {
                dtvg.DataSource = ds;
                dtvg.Columns[0].HeaderText = "IDpro";
                dtvg.Columns[1].HeaderText = "IDware";
                dtvg.Columns[2].HeaderText = "Dayadded";
                dtvg.Columns[3].HeaderText = "Exporttdate";
                dtvg.Columns[4].HeaderText = "Quantity";
                dtvg.Columns[5].HeaderText = "Importprice";
                dtvg.Columns[6].HeaderText = "Exportprice";
            }
            else
            {
                MessageBox.Show("Không tìm thấy nhân viên", "Thông báo",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            txttimkiem.Text = "Enter someone name...";
            txttimkiem.BackColor = Color.LightGray;
            
        }
    }
}
