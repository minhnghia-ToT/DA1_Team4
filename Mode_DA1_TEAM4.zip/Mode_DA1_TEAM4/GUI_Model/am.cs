﻿using BUS;
using DTO;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net.Mail;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ListView;

namespace GUI_Model
{
    public partial class am : Form
    {
        BUS_Staff staff = new BUS_Staff();
        public am()
        {
            InitializeComponent();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }



        private void am_Load(object sender, EventArgs e)
        {
            ResetValues();
            LoadGridview();
        }
        private void LoadGridview()
        {
            dtgvStaff.DataSource = staff.getNhanVien();
            dtgvStaff.Columns[0].HeaderText = "ID";
            dtgvStaff.Columns[1].HeaderText = "Name";
            dtgvStaff.Columns[2].HeaderText = "Password";
            dtgvStaff.Columns[3].HeaderText = "Email";
            dtgvStaff.Columns[4].HeaderText = "ID Role";
        }
        private void ResetValues()
        {
            txttimKiem.Text = "Enter staff name...";
            txtEmail.Text = null;
            txtname.Text = null;
            txtPass.Text = null;

            txtEmail.Enabled = false;
            txtname.Enabled = false;
            txtPass.Enabled = false;
            rbAdmin.Enabled = false;
            rbStaff.Enabled = false;
            btnThem.Enabled = true;
            btnLuu.Enabled = false;
            btnDong.Enabled = true;
            btnSua.Enabled = false;
            btnXoa.Enabled = false;
        }
        private void btnLuu_Click(object sender, EventArgs e)
        {
            string email;
            int role;

            // Gán role dựa vào RadioButton được chọn
            if (rbAdmin.Checked == true)
            {
                role = 1; // Quản trị
            }
            else if (rbStaff.Checked == true)
            {
                role = 2; // Nhân viên
            }
            else
            {
                MessageBox.Show("Bạn phải chọn vai trò nhân viên", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return; // Thoát khỏi hàm nếu không chọn vai trò
            }

            // Kiểm tra email
            if (txtEmail.Text.Trim().Length == 0)
            {
                MessageBox.Show("Bạn phải nhập email", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                txtEmail.Focus();
                return;
            }
            else if (!IsValid(txtEmail.Text.Trim()))
            {
                MessageBox.Show("Bạn phải nhập đúng định dạng email", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                txtEmail.Focus();
                return;
            }

            // Kiểm tra tên nhân viên
            if (txtname.Text.Trim().Length == 0)
            {
                MessageBox.Show("Bạn phải nhập tên nhân viên", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                txtname.Focus();
                return;
            }

            // Kiểm tra mật khẩu
            if (txtPass.Text.Trim().Length == 0)
            {
                MessageBox.Show("Bạn phải nhập mật khẩu", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                txtPass.Focus();
                return;
            }

            // Tạo DTO và thêm nhân viên
            DTO_Staff dto = new DTO_Staff(txtname.Text, txtEmail.Text, txtPass.Text, role);
            if (staff.insertNhanVien(dto))
            {
                MessageBox.Show("Thêm thành công");
                ResetValues();
                LoadGridview();
                email = txtEmail.Text;
            }
            else
            {
                MessageBox.Show("Thêm không thành công");
            }
        }

        private void btnDong_Click(object sender, EventArgs e)
        {
            this.Close();
            admin admin = new admin();
            admin.Close();
        }

        private void dtgvStaff_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            //dtgvStaff.ForeColor = Color.Black;
            //if (dtgvStaff.Rows.Count > 1)
            //{
            //    btnLuu.Enabled = false;
            //    txtname.Enabled = true;
            //    rbAdmin.Enabled = true;
            //    rbStaff.Enabled = true;
            //    btnSua.Enabled = true;
            //    btnXoa.Enabled = true;
            //    //show data from selected row to controls
            //    txtEmail.Text = dtgvStaff.CurrentRow.Cells["email"].Value.ToString();
            //    txtname.Text = dtgvStaff.CurrentRow.Cells["ten"].Value.ToString();
            //    txtPass.Text = dtgvStaff.CurrentRow.Cells["matkhau"].Value.ToString();
            //    if (int.Parse(dtgvStaff.CurrentRow.Cells["IDQuyen"].Value.ToString()) == 1)
            //        rbAdmin.Checked = true;
            //    else
            //        rbStaff.Checked = true;
            //}
            //else
            //{
            //    MessageBox.Show("Bảng không tồn tại dữ liệu", "Thông báo", MessageBoxButtons.OK,
            //        MessageBoxIcon.Information);
            //}
        }
        private void dgvStaff_Click(object sender, EventArgs e)
        {
            //if (dtgvStaff.SelectedRows.Count > 0)
            //{
            //    btnLuu.Enabled = false;
            //    txtname.Enabled = true;
            //    rbAdmin.Enabled = true;
            //    rbStaff.Enabled = true;
            //    btnSua.Enabled = true;
            //    btnXoa.Enabled = true;

            //    // Lấy hàng đang được chọn
            //    DataGridViewRow selectedRow = dtgvStaff.SelectedRows[0];

            //    // Hiển thị dữ liệu từ hàng đã chọn lên các controls
            //    txtEmail.Text = selectedRow.Cells["Email"].Value.ToString();
            //    txtname.Text = selectedRow.Cells["Ten"].Value.ToString();
            //    txtPass.Text = selectedRow.Cells["Password"].Value.ToString();

            //    // Cập nhật RadioButton dựa trên IDQuyen
            //    if (int.Parse(selectedRow.Cells["IDQuyen"].Value.ToString()) == 1)
            //    {
            //        rbAdmin.Checked = true;
            //        rbStaff.Checked = false;
            //    }
            //    else
            //    {
            //        rbStaff.Checked = true;
            //        rbAdmin.Checked = false;
            //    }

            //    this.Refresh();
            //}
            //else
            //{
            //    MessageBox.Show("Bảng không tồn tại dữ liệu", "Thông báo", MessageBoxButtons.OK,
            //        MessageBoxIcon.Information);
            //}
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            admin admin = new admin();
            admin.Show();
            this.Close();
        }

        private void btnThem_Click(object sender, EventArgs e)
        {
            txtEmail.Text = null;
            txtname.Text = null;
            txtPass.Text = null;
            txtname.Enabled = true;
            txtEmail.Enabled = true;
            txtPass.Enabled = true;

            rbAdmin.Enabled = true;
            rbStaff.Enabled = true;
            btnLuu.Enabled = true;
            btnSua.Enabled = false;
            btnXoa.Enabled = false;
            rbStaff.Checked = false;
            rbAdmin.Checked = false;
            txtEmail.Focus();
        }
        public bool IsValid(string emailaddress)// check rule email
        {
            try
            {
                MailAddress m = new MailAddress(emailaddress);

                return true;
            }
            catch (FormatException)
            {
                return false;
            }
        }
        private void btnBoqua_Click(object sender, EventArgs e)
        {
            ResetValues();
            LoadGridview();
        }

        private void btnSua_Click(object sender, EventArgs e)
        {
            if (txtname.Text.Trim().Length == 0)// kiem tra phai nhap data
            {
                MessageBox.Show("Bạn phải nhập tên nhân viên", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                txtname.Focus();
                return;
            }
            else if (txtPass.Text.Trim().Length == 0)
            {
                MessageBox.Show("Bạn phải nhập mật khẩu", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                txtPass.Focus();
                return;
            }
            else if (txtEmail.Text.Trim().Length == 0)
            {
                MessageBox.Show("Bạn phải nhập Email", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                txtEmail.Focus();
                return;
            }
            else
            {
                int role = 2;//vai tro nhan vien
                if (rbAdmin.Checked)
                    role = 1;//quản trị
                // Tạo DTo
                DTO_Staff nv = new DTO_Staff(txtname.Text, txtEmail.Text, txtPass.Text, role); // Vì ID tự tăng nên để ID số gì cũng dc
                if (MessageBox.Show("Bạn có chắc muốn chỉnh sửa", "Confirm", MessageBoxButtons.YesNo, MessageBoxIcon.Question)
                    == DialogResult.Yes)
                {
                    //do something if YES
                    if (staff.updateNhanVien(nv))
                    {
                        MessageBox.Show("Sửa thành công");
                        ResetValues();
                        LoadGridview(); // refresh datagridview
                    }
                    else
                    {
                        MessageBox.Show("Sửa không thành công");
                    }
                }
                else
                {
                    ResetValues();
                }
            }
        }

        private void btnXoa_Click(object sender, EventArgs e)
        {
            string email = txtEmail.Text;
            if (MessageBox.Show("Bạn có chắc muốn xóa dữ liệu", "Confirm",
                MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                //do something if YES
                if (staff.DeleteNhanVien(email))
                {
                    MessageBox.Show("Xóa dữ liệu thành công");
                    ResetValues();
                    LoadGridview();
                }
                else
                {
                    MessageBox.Show("Xóa không thành công");
                }
            }
            else
            {
                //do something if NO
                ResetValues();
            }
        }

        private void btnTimkiem_Click(object sender, EventArgs e)
        {
            string tenNhanvien = txttimKiem.Text;// tìm theo tên
            DataTable ds = staff.SearchNhanVien(tenNhanvien);
            if (ds.Rows.Count > 0) // tìm thấy kết quả => load lên
            {
                dtgvStaff.DataSource = ds;
                dtgvStaff.Columns[0].HeaderText = "ID";
                dtgvStaff.Columns[1].HeaderText = "Name";
                dtgvStaff.Columns[2].HeaderText = "Password";
                dtgvStaff.Columns[3].HeaderText = "Email";
                dtgvStaff.Columns[4].HeaderText = "ID Role";
            }
            else
            {
                MessageBox.Show("Không tìm thấy nhân viên", "Thông báo",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            txttimKiem.Text = "Enter staff name...";
            txttimKiem.BackColor = Color.LightGray;
            ResetValues();
        }

        private void dtgvStaff_Click(object sender, EventArgs e)
        {
            if (dtgvStaff.SelectedRows.Count > 0)
            {
                btnLuu.Enabled = false;
                txtname.Enabled = true;
                txtPass.Enabled = true;
                txtEmail.Enabled = true;
                rbAdmin.Enabled = true;
                rbStaff.Enabled = true;
                btnSua.Enabled = true;
                btnXoa.Enabled = true;

                // Lấy hàng đang được chọn
                DataGridViewRow selectedRow = dtgvStaff.SelectedRows[0];

                // Hiển thị dữ liệu từ hàng đã chọn lên các controls
                txtEmail.Text = selectedRow.Cells["Email"].Value.ToString();
                txtname.Text = selectedRow.Cells["Ten"].Value.ToString();
                txtPass.Text = selectedRow.Cells["Matkhau"].Value.ToString();

                // Cập nhật RadioButton dựa trên IDQuyen
                if (int.Parse(selectedRow.Cells["IDQuyen"].Value.ToString()) == 1)
                {
                    rbAdmin.Checked = true;
                    rbStaff.Checked = false;
                }
                else
                {
                    rbStaff.Checked = true;
                    rbAdmin.Checked = false;
                }

                this.Refresh();
            }
            else
            {
                MessageBox.Show("Bảng không tồn tại dữ liệu", "Thông báo", MessageBoxButtons.OK,
                    MessageBoxIcon.Information);
            }
        }

        private void txtPass_TextChanged(object sender, EventArgs e)
        {
            txtPass.PasswordChar = '*';
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            AAM ad = new AAM();
            ad.Show();
            this.Hide();
        }
    }
}
