﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;

namespace DAL
{
    public class DAL_ChiCart
    {
        private string connectionString;

        public DAL_ChiCart(string connectionString)
        {
            this.connectionString = connectionString;
        }
        public DataTable GetChiTietGioHangIDGioHang(int idGioHang)
        {
            DataTable dt = new DataTable();
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand command = new SqlCommand("SELECT * FROM ChiTietGioHang", connection);
                command.Parameters.AddWithValue("@IDGioHang", idGioHang);
                SqlDataAdapter adapter = new SqlDataAdapter(command);
                adapter.Fill(dt);
            }
            return dt;
        }

        public void Insert_ChiTietGioHang(int idGioHang, int idSanPham, int soLuong, decimal gia)
        {
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                SqlCommand cmd = new SqlCommand("Insert_ChiTietGioHang", conn);
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.AddWithValue("@IDGioHang", idGioHang);
                cmd.Parameters.AddWithValue("@IDSanPham", idSanPham);
                cmd.Parameters.AddWithValue("@SoLuong", soLuong);
                cmd.Parameters.AddWithValue("@Gia", gia);

                conn.Open();
                cmd.ExecuteNonQuery();
            }
        }

        public void Update_ChiTietGioHang(int idChiTietGioHang, int soLuong, decimal gia)
        {
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                SqlCommand cmd = new SqlCommand("Update_ChiTietGioHang", conn);
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.AddWithValue("@IDChiTietGioHang", idChiTietGioHang);
                cmd.Parameters.AddWithValue("@SoLuong", soLuong);
                cmd.Parameters.AddWithValue("@Gia", gia);

                conn.Open();
                cmd.ExecuteNonQuery();
            }
        }

        public void Delete_ChiTietGioHang(int idChiTietGioHang)
        {
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                SqlCommand cmd = new SqlCommand("Delete_ChiTietGioHang", conn);
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.AddWithValue("@IDChiTietGioHang", idChiTietGioHang);

                conn.Open();
                cmd.ExecuteNonQuery();
            }
        }
    }
}
