﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Security.Cryptography.X509Certificates;
using DTO;

namespace DAL
{
    public class DAL_Product : DBConnect
    {
        public DataTable getProd()
        {
            try
            {
                _conn.Open();
                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "DanhSachHang";
                cmd.Connection = _conn;
                DataTable dtHang = new DataTable();
                dtHang.Load(cmd.ExecuteReader());
                return dtHang;
            }
            finally
            {
                _conn.Close();
            }

        }
        public bool Insert_SanPham (DTO_product  prod)
        {
            try
            {
                _conn.Open();
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = _conn;
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "insert_SanPham";
                cmd.Parameters.AddWithValue("HinhAnh", prod.IMG);
                cmd.Parameters.AddWithValue("Ten", prod.Nameproduct);
                cmd.Parameters.AddWithValue("MieuTa", prod.Priceproduct);
                cmd.Parameters.AddWithValue("Gia", prod.Describeproduct);
                cmd.Parameters.AddWithValue("SoLuong",prod.Quantityproduct);
                if (cmd.ExecuteNonQuery() > 0)
                {
                    return true;
                }
            }
            finally
            {
                _conn.Close();
            }
            return false;
        }
        public bool Update_SanPham (DTO_product prod)
        {
            try
            {
                _conn.Open();
                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Connection = _conn;
                cmd.CommandText = "UpdateNhanVien";
                cmd.Parameters.AddWithValue("Ten", prod.Nameproduct);
                cmd.Parameters.AddWithValue("Gia", prod.Priceproduct);
                cmd.Parameters.AddWithValue("MieuTa", prod.Describeproduct);
                cmd.Parameters.AddWithValue("HinhAnh", prod.IMG);
                cmd.Parameters.AddWithValue("SoLuong", prod.Quantityproduct);
                if (cmd.ExecuteNonQuery() > 0)
                {
                    return true;
                }
            }
            finally { _conn.Close(); }
            return false;
        }
    }
    
}

