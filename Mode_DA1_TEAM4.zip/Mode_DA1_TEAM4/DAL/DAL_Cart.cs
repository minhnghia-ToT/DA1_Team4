﻿using System;
using System.Data;
using System.Data.SqlClient;

namespace DAL
{
    public class DAL_Cart
    {
        private string connectionString;

        public DAL_Cart(string connectionString)
        {
            this.connectionString = connectionString;
        }

        public DataTable GetGioHang()
        {
            DataTable dt = new DataTable();
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand command = new SqlCommand("DanhSachGioHang", connection);
                command.CommandType = CommandType.StoredProcedure;
                SqlDataAdapter adapter = new SqlDataAdapter(command);
                adapter.Fill(dt);
            }
            return dt;
        }

        public void Insert_GioHang(int idNhanVien, DateTime ngayTao)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand command = new SqlCommand("Insert_GioHang", connection);
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.AddWithValue("@IDNhanVien", idNhanVien);
                command.Parameters.AddWithValue("@NgayTao", ngayTao);
                connection.Open();
                command.ExecuteNonQuery();
            }
        }

        public void Update_GioHang(int idGioHang, int idNhanVien, DateTime ngayTao)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand command = new SqlCommand("Update_GioHang", connection);
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.AddWithValue("@IDGioHang", idGioHang);
                command.Parameters.AddWithValue("@IDNhanVien", idNhanVien);
                command.Parameters.AddWithValue("@NgayTao", ngayTao);
                connection.Open();
                command.ExecuteNonQuery();
            }
        }

        public void Delete_GioHang(int idGioHang)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand command = new SqlCommand("Delete_GioHang", connection);
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.AddWithValue("@IDGioHang", idGioHang);
                connection.Open();
                command.ExecuteNonQuery();
            }
        }
    }
}
