﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAL
{
    public class DAL_wareH : DBConnect
    {
       public DataTable GetKhoData()
        {
            try
            {
                _conn.Open();
                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "GetkhoData";
                cmd.Connection = _conn;
                DataTable dtwh = new DataTable();
                dtwh.Load(cmd.ExecuteReader());
                return dtwh;
            }
           finally { _conn.Close(); }
        }
       public DataTable seach_Kho(string keyword) 
        {
            try
            {
                _conn = new SqlConnection();
                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "timkiem";
                cmd.Connection = _conn;
                DataTable dtwh = new DataTable();   
                dtwh.Load(cmd.ExecuteReader());
                return dtwh;    
            }
            finally { _conn.Close(); }
            
        }
    }
}
