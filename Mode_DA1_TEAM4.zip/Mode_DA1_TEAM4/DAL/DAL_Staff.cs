﻿using DTO;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAL
{
    public class DAL_Staff : DBConnect
    {
        //login
        public bool StaffLogin(DTO_Staff staff)
        {
            try
            {
                _conn.Open();
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = _conn;
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "DangNhap";
                cmd.Parameters.AddWithValue("email", staff.EMAIL);
                cmd.Parameters.AddWithValue("matkhau", staff.Password);

                // Lấy kết quả là IDQuyen (hoặc 0 nếu không khớp)
                int result = Convert.ToInt32(cmd.ExecuteScalar());

                // Gán IDQuyen cho đối tượng staff
                staff.IDQuyen = result;

                // Kiểm tra đăng nhập thành công dựa trên IDQuyen
                if (result > 0)
                {
                    return true; // Đăng nhập thành công
                }

                return false; // Không khớp IDQuyen
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                return false;
            }
            finally
            {
                _conn.Close();
            }
        }

        // Hàm kiểm tra quyền truy cập
        public bool CheckPermission(DTO_Staff staff, int requiredPermission)
        {
            return staff.IDQuyen == requiredPermission;
        }
        public DataTable getNhanVien()
        {
            try
            {
                _conn.Open();
                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "DanhSachNV";
                cmd.Connection = _conn;
                DataTable dtNV = new DataTable();
                dtNV.Load(cmd.ExecuteReader());
                return dtNV;
            }
            finally { _conn.Close(); }
        }
        public DataTable getAdmin()
        {
            try
            {
                _conn.Open();
                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "DanhSachAd";
                cmd.Connection = _conn;
                DataTable dtNV = new DataTable();
                dtNV.Load(cmd.ExecuteReader());
                return dtNV;
            }
            finally { _conn.Close(); }
        }
        public bool DeleteNhanVien(string Email)
        {
            try
            {
                _conn.Open();
                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Connection = _conn;
                cmd.CommandText = "DeleteNhanVien";
                cmd.Parameters.AddWithValue("Email", Email);
                if (cmd.ExecuteNonQuery() > 0)
                {
                    return true;
                }

            }
            finally { _conn.Close(); }
            return false;
        }
        public bool DeleteAdmin(string Email)
        {
            try
            {
                _conn.Open();
                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Connection = _conn;
                cmd.CommandText = "DeleteAdmin";
                cmd.Parameters.AddWithValue("Email", Email);
                if (cmd.ExecuteNonQuery() > 0)
                {
                    return true;
                }

            }
            finally { _conn.Close(); }
            return false;
        }
        public bool Insert_NV(DTO_Staff nv)
        {
            try
            {
                _conn.Open();
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = _conn;
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "InsertNhanVien";
                cmd.Parameters.AddWithValue("Ten", nv.staffName);
                cmd.Parameters.AddWithValue("Matkhau", nv.Password);
                cmd.Parameters.AddWithValue("Email", nv.EMAIL);
                if (cmd.ExecuteNonQuery() > 0)
                {
                    return true;
                }
            }
            finally
            {
                _conn.Close();
            }
            return false;
        }
        public bool Insert_Admin(DTO_Staff nv)
        {
            try
            {
                _conn.Open();
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = _conn;
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "InsertAdmin";
                cmd.Parameters.AddWithValue("Ten", nv.staffName);
                cmd.Parameters.AddWithValue("Matkhau", nv.Password);
                cmd.Parameters.AddWithValue("Email", nv.EMAIL);
                if (cmd.ExecuteNonQuery() > 0)
                {
                    return true;
                }
            }
            finally
            {
                _conn.Close();
            }
            return false;
        }
        public DataTable Search_NV(string TenNV)
        {
            try
            {
                _conn.Open();
                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "SearchNhanVien";
                cmd.Parameters.AddWithValue("Ten", TenNV);
                cmd.Connection = _conn;
                DataTable dtNV1 = new DataTable();
                dtNV1.Load(cmd.ExecuteReader());
                return dtNV1;
            }
            finally { _conn.Close(); }
        }
        public DataTable Search_Admin(string TenNV)
        {
            try
            {
                _conn.Open();
                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "SearchAdmin";
                cmd.Parameters.AddWithValue("Ten", TenNV);
                cmd.Connection = _conn;
                DataTable dtNV1 = new DataTable();
                dtNV1.Load(cmd.ExecuteReader());
                return dtNV1;
            }
            finally { _conn.Close(); }
        }
        public bool Update_NV(DTO_Staff Nv)
        {
            try
            {
                _conn.Open();
                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Connection = _conn;
                cmd.CommandText = "UpdateNhanVien";
                cmd.Parameters.AddWithValue("Ten", Nv.staffName);
                cmd.Parameters.AddWithValue("MatKhau", Nv.Password);
                cmd.Parameters.AddWithValue("Email", Nv.EMAIL);
                if (cmd.ExecuteNonQuery() > 0)
                {
                    return true;
                }
            }
            finally { _conn.Close(); }
            return false;
        }
        public bool Update_Admin(DTO_Staff Nv)
        {
            try
            {
                _conn.Open();
                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Connection = _conn;
                cmd.CommandText = "UpdateAdmin";
                cmd.Parameters.AddWithValue("Ten", Nv.staffName);
                cmd.Parameters.AddWithValue("MatKhau", Nv.Password);
                cmd.Parameters.AddWithValue("Email", Nv.EMAIL);
                if (cmd.ExecuteNonQuery() > 0)
                {
                    return true;
                }
            }
            finally { _conn.Close(); }
            return false;
        }
    }
}