﻿using DTO;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAL
{
    public class DAL_Staff : DBConnect
    {
        //login
        public bool StaffLogin(DTO_Staff staff)
        {
            try
            {
                _conn.Open();
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = _conn;
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "DangNhap";
                cmd.Parameters.AddWithValue("email", staff.EMAIL);
                cmd.Parameters.AddWithValue("matkhau", staff.Password);

                // Lấy kết quả là IDQuyen (hoặc 0 nếu không khớp)
                int result = Convert.ToInt32(cmd.ExecuteScalar());

                // Gán IDQuyen cho đối tượng staff
                staff.IDQuyen = result;

                // Kiểm tra đăng nhập thành công dựa trên IDQuyen
                return result > 0;
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                return false;
            }
            finally
            {
                _conn.Close();
            }
        }
    }
}