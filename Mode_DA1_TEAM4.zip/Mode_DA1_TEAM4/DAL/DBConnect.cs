﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient; 
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace DAL
{
    public class DBConnect
    {
        protected SqlConnection _conn = new SqlConnection(@"Data Source=NhatAnhne;Initial Catalog=QQQ;User ID=sa;Password=***********;Integrated Security=True;");
    }

}