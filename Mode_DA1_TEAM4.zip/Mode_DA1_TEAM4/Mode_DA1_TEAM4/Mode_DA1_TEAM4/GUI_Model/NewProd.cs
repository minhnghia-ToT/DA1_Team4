﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GUI_Model
{
    public partial class NewProd : Form
    {
        public NewProd()
        {
            InitializeComponent();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            banhang bh = new banhang();
            bh.Show();
            this.Close();
        }

        private void NewProd_Load(object sender, EventArgs e)
        {

        }
    }
}
