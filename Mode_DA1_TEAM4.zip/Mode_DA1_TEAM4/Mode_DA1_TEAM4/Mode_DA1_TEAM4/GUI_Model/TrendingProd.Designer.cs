﻿namespace GUI_Model
{
    partial class TrendingProd
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(TrendingProd));
            button5 = new Button();
            groupBox4 = new GroupBox();
            label4 = new Label();
            pictureBox4 = new PictureBox();
            groupBox3 = new GroupBox();
            label3 = new Label();
            pictureBox3 = new PictureBox();
            groupBox2 = new GroupBox();
            label2 = new Label();
            pictureBox2 = new PictureBox();
            groupBox1 = new GroupBox();
            label1 = new Label();
            pictureBox1 = new PictureBox();
            groupBox4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox4).BeginInit();
            groupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).BeginInit();
            groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // button5
            // 
            button5.BackColor = Color.LightCyan;
            button5.Font = new Font("Agency FB", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button5.ForeColor = Color.LightSeaGreen;
            button5.Image = (Image)resources.GetObject("button5.Image");
            button5.Location = new Point(42, 342);
            button5.Name = "button5";
            button5.Size = new Size(1268, 96);
            button5.TabIndex = 16;
            button5.TextAlign = ContentAlignment.BottomRight;
            button5.UseVisualStyleBackColor = false;
            button5.Click += button5_Click;
            // 
            // groupBox4
            // 
            groupBox4.BackColor = Color.Ivory;
            groupBox4.Controls.Add(label4);
            groupBox4.Controls.Add(pictureBox4);
            groupBox4.Font = new Font("Century", 10.2F, FontStyle.Regular, GraphicsUnit.Point, 0);
            groupBox4.Location = new Point(1072, 12);
            groupBox4.Name = "groupBox4";
            groupBox4.Size = new Size(238, 324);
            groupBox4.TabIndex = 12;
            groupBox4.TabStop = false;
            groupBox4.Text = "Banshee Gundam";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Century", 19.8000011F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label4.Location = new Point(13, 274);
            label4.Name = "label4";
            label4.Size = new Size(219, 40);
            label4.TabIndex = 1;
            label4.Text = "850.000VND";
            // 
            // pictureBox4
            // 
            pictureBox4.BorderStyle = BorderStyle.FixedSingle;
            pictureBox4.Image = (Image)resources.GetObject("pictureBox4.Image");
            pictureBox4.Location = new Point(21, 27);
            pictureBox4.Name = "pictureBox4";
            pictureBox4.Size = new Size(195, 244);
            pictureBox4.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox4.TabIndex = 0;
            pictureBox4.TabStop = false;
            // 
            // groupBox3
            // 
            groupBox3.BackColor = Color.Ivory;
            groupBox3.Controls.Add(label3);
            groupBox3.Controls.Add(pictureBox3);
            groupBox3.Font = new Font("Century", 10.2F, FontStyle.Regular, GraphicsUnit.Point, 0);
            groupBox3.Location = new Point(736, 12);
            groupBox3.Name = "groupBox3";
            groupBox3.Size = new Size(238, 324);
            groupBox3.TabIndex = 13;
            groupBox3.TabStop = false;
            groupBox3.Text = "RX 78-2 Gundam";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Century", 19.8000011F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label3.Location = new Point(13, 274);
            label3.Name = "label3";
            label3.Size = new Size(219, 40);
            label3.TabIndex = 1;
            label3.Text = "200.000VND";
            // 
            // pictureBox3
            // 
            pictureBox3.BorderStyle = BorderStyle.FixedSingle;
            pictureBox3.Image = (Image)resources.GetObject("pictureBox3.Image");
            pictureBox3.Location = new Point(21, 27);
            pictureBox3.Name = "pictureBox3";
            pictureBox3.Size = new Size(195, 244);
            pictureBox3.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox3.TabIndex = 0;
            pictureBox3.TabStop = false;
            // 
            // groupBox2
            // 
            groupBox2.BackColor = Color.Ivory;
            groupBox2.Controls.Add(label2);
            groupBox2.Controls.Add(pictureBox2);
            groupBox2.Font = new Font("Century", 10.2F, FontStyle.Regular, GraphicsUnit.Point, 0);
            groupBox2.Location = new Point(387, 12);
            groupBox2.Name = "groupBox2";
            groupBox2.Size = new Size(238, 324);
            groupBox2.TabIndex = 14;
            groupBox2.TabStop = false;
            groupBox2.Text = "Astray Gundam";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Century", 19.8000011F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label2.Location = new Point(13, 274);
            label2.Name = "label2";
            label2.Size = new Size(219, 40);
            label2.TabIndex = 1;
            label2.Text = "350.000VND";
            // 
            // pictureBox2
            // 
            pictureBox2.BorderStyle = BorderStyle.FixedSingle;
            pictureBox2.Image = (Image)resources.GetObject("pictureBox2.Image");
            pictureBox2.Location = new Point(21, 27);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(195, 244);
            pictureBox2.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox2.TabIndex = 0;
            pictureBox2.TabStop = false;
            // 
            // groupBox1
            // 
            groupBox1.BackColor = Color.Ivory;
            groupBox1.Controls.Add(label1);
            groupBox1.Controls.Add(pictureBox1);
            groupBox1.Font = new Font("Century", 10.2F, FontStyle.Regular, GraphicsUnit.Point, 0);
            groupBox1.Location = new Point(42, 12);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(238, 324);
            groupBox1.TabIndex = 15;
            groupBox1.TabStop = false;
            groupBox1.Text = "Ariel Gundam";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Century", 19.8000011F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label1.Location = new Point(13, 274);
            label1.Name = "label1";
            label1.Size = new Size(219, 40);
            label1.TabIndex = 1;
            label1.Text = "400.000VND";
            // 
            // pictureBox1
            // 
            pictureBox1.BorderStyle = BorderStyle.FixedSingle;
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(21, 27);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(195, 244);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 0;
            pictureBox1.TabStop = false;
            // 
            // TrendingProd
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.MediumBlue;
            BackgroundImage = (Image)resources.GetObject("$this.BackgroundImage");
            ClientSize = new Size(1353, 450);
            Controls.Add(button5);
            Controls.Add(groupBox4);
            Controls.Add(groupBox3);
            Controls.Add(groupBox2);
            Controls.Add(groupBox1);
            Name = "TrendingProd";
            Text = "TrendingProd";
            groupBox4.ResumeLayout(false);
            groupBox4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox4).EndInit();
            groupBox3.ResumeLayout(false);
            groupBox3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).EndInit();
            groupBox2.ResumeLayout(false);
            groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private Button button5;
        private GroupBox groupBox4;
        private Label label4;
        private PictureBox pictureBox4;
        private GroupBox groupBox3;
        private Label label3;
        private PictureBox pictureBox3;
        private GroupBox groupBox2;
        private Label label2;
        private PictureBox pictureBox2;
        private GroupBox groupBox1;
        private Label label1;
        private PictureBox pictureBox1;
    }
}