﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GUI_Model
{
    public partial class warehouse : Form
    {
        public warehouse()
        {
            InitializeComponent();
        }

        private void warehouse_Load(object sender, EventArgs e)
        {

        }

        private void button6_Click(object sender, EventArgs e)
        {
            admin ad = new admin();
            ad.Show();
            this.Close();
        }
    }
}
