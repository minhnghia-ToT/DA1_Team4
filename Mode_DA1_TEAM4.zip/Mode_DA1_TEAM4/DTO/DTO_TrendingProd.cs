﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DTO
{
    public class DTO_TrendingProd
    {
        private int ID;
        private string Name;
        private string Describe;
        private int Price;
        private int Quantity;

        public int IDprod
        {
            get
            {
                return ID;
            }
            set
            {
                ID = value;
            }
        }
        public string prodName
        {
            get
            {
                return Name;
            }
            set
            {
                Name = value;
            }
        }

        public string Des
        {
            get
            {
                return Describe;
            }
            set
            {
                Describe = value;
            }
        }
        public int price
        {
            get
            {
                return Price;
            }
            set
            {
                Price = value;
            }
        }
        public int quantity
        {
            get
            {
                return Quantity;
            }
            set
            {
                Quantity = value;
            }
        }



        public DTO_TrendingProd(int ID, string Name, string Describe, int Price, int Quantity)
        {
            this.ID = ID;
            this.Name = Name;
            this.Describe = Describe;
            this.Price = Price;
            this.Quantity = Quantity;
        }

        public DTO_TrendingProd()
        {

        }
    }
}
