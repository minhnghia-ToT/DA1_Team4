﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DTO
{
    public class DTO_wareH
    {
        private int IDpro;
        private int IDwareH;
        private string Dayadded;
        private string Exporttdate;
        private int Quantity;
        private int Importprice;
        private int Exportprice;

        public int IDPro
        {
            get
            {
                return IDpro;
            }
            set
            {
                IDpro = value;
            }
        }

        public int IDWareH
        {
            get
            {
                return IDwareH;
            }
            set
            {
                IDwareH = value;
            }
        }

        public string DayAdded
        {
            get
            {
                return Dayadded;
            }
            set
            {
                Dayadded = value;
            }
        }

        public string ExportDate
        {
            get
            {
                return Exporttdate;
            }
            set
            {
                Exporttdate = value;
            }
        }

        public int quantity
        {
            get
            {
                return Quantity;
            }
            set
            {
                Quantity = value;
            }
        }

        public int ImportPrice
        {
            get
            {
                return Importprice;
            }
            set
            {
                Importprice = value;
            }
        }

        public int ExportPrice
        {
            get
            {
                return Exportprice;
            }
            set
            {
                Exportprice = value;
            }
        }
        public DTO_wareH (int IDprod, int IDwareH, string Dayadded, string Exporttdate, int Quantity,int Importprice, int Exportprice)
        { 
            this.IDPro = IDprod;
            this.IDWareH = IDwareH;
            this.DayAdded = Dayadded;
            this.ExportDate = Exporttdate;
            this.Exportprice = Exportprice;
            this.Quantity = Quantity;   
            this.Importprice = Importprice; 
        }
    public DTO_wareH()
        {

        }
    }
   
}

