﻿using System;

namespace DTO
{
    public class DTO_product
    {
        private int _IDproduct;
        private string _Image;
        private string _Name;
        private string _Describe;
        private int _Price;
        private int _Quantity;
        private int productId;
        private string imageName;
        private string productName;

        // Using Idprod for consistency
        public int Idprod
        {
            get { return _IDproduct; }
            set { _IDproduct = value; }
        }

        public string IMG
        {
            get { return _Image; }
            set { _Image = value; }
        }

        public string Nameproduct
        {
            get { return _Name; }
            set { _Name = value; }
        }

        public int Priceproduct
        {
            get { return _Price; }
            set { _Price = value; }
        }

        public string Describeproduct
        {
            get { return _Describe; }
            set { _Describe = value; }
        }

        public int Quantityproduct
        {
            get { return _Quantity; }
            set { _Quantity = value; }
        }

        // Constructor using Idprod consistently
        public DTO_product(int Idprod, string Name, string Describe, string Image, int Price, int Quantity)
        {
            this.Idprod = Idprod;
            this.Nameproduct = Name;
            this.Describeproduct = Describe;
            this.IMG = Image;
            this.Priceproduct = Price;
            this.Quantityproduct = Quantity;
        }

        public DTO_product()
        {
            // Default constructor - good practice to have
        }

        public DTO_product(int productId, string imageName, string productName)
        {
            this.productId = productId;
            this.imageName = imageName;
            this.productName = productName;
        }
    }
}