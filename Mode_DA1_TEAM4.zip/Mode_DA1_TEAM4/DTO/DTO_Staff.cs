﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DTO
{
    public class DTO_Staff
    {
        private int ID;
        private string Name;
        private string Email;
        private string Pass;
        private int IDq;

        public int IDstaff
        {
            get
            {
                return ID;
            }
            set
            {
                ID = value;
            }
        }
        public string staffName
        {
            get
            {
                return Name;
            }
            set
            {
                Name = value;
            }
        }

        public string EMAIL
        {
            get
            {
                return Email;
            }
            set
            {
                Email = value;
            }
        }
        public string Password
        {
            get
            {
                return Pass;
            }
            set
            {
                Pass = value;
            }
        }
        public int IDQuyen
        {
            get 
            { 
                return IDq; 
            }
            set
            {
                IDq = value;
            }
        }



        public DTO_Staff(int ID, string Name, string Email, string Pass, int IDq)
        {
            this.ID = ID;
            this.Name = Name;
            this.Email = Email;
            this.Pass = Pass;
            this.IDq = IDq;
        }

        public DTO_Staff()
        {

     
        }
    }
}
