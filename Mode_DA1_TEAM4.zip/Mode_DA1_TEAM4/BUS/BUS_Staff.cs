﻿using DAL;
using DTO;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace BUS
{
    public class BUS_Staff
    {
        DAL_Staff dal = new DAL_Staff();
        public bool StaffLogin(DTO_Staff nv)
        {
            return dal.StaffLogin(nv);
        }
        public DataTable getNhanVien()
        {
            return dal.getNhanVien();
        }
        public bool insertNhanVien(DTO_Staff nv)
        {
            return dal.Insert_NV(nv);
        }
        public DataTable SearchNhanVien(string TenNV)
        {
            return dal.Search_NV(TenNV);
        }
        public bool updateNhanVien(DTO_Staff Nv)
        {
            return dal.Update_NV(Nv);
        }
        public bool DeleteNhanVien(string email)
        {
            return dal.DeleteNhanVien(email);
        }
        public DataTable getAdmin()
        {
            return dal.getAdmin();
        }
        public bool insertAdmin(DTO_Staff nv)
        {
            return dal.Insert_Admin(nv);
        }
        public DataTable SearchAdmin(string TenNV)
        {
            return dal.Search_Admin(TenNV);
        }
        public bool updateAdmin(DTO_Staff Nv)
        {
            return dal.Update_Admin(Nv);
        }
        public bool DeleteAdmin(string email)
        {
            return dal.DeleteAdmin(email);
        }
    }
}