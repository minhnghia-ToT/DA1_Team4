﻿using DAL;
using DTO;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace BUS
{
    public class BUS_Staff
    {
        DAL_Staff dalogin = new DAL_Staff();
        public bool StaffLogin(DTO_Staff nv)
        {
            return dalogin.StaffLogin(nv);
        }
        

        
        //public DataTable getNhanVien()
        //{
        //    return dalNhanVien.getNhanVien();
        //}
        //public bool insertNhanVien(DTONhanVien nv)
        //{
        //    return dalNhanVien.Insert_NV(nv);
        //}
        //public DataTable SearchNhanVien(string TenNV)
        //{
        //    return dalNhanVien.Search_NV(TenNV);
        //}
        //public bool updateNhanVien(DTONhanVien Nv)
        //{
        //    return dalNhanVien.Update_NV(Nv);
        //}
        //public bool DeleteNhanVien(string email)
        //{
        //    return dalNhanVien.Delete_NV(email);
        //}
    }
}