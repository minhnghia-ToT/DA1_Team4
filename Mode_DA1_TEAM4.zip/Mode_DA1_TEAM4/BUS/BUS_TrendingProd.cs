﻿using DAL;
using DTO;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BUS
{
    public class BUS_TrendingProd
    {
        DAL_TrendingProd dal = new DAL_TrendingProd();
        public DataTable getTopSP()
        {
            return dal.getTrendingProd();
        }
    }
}
