﻿using DAL;
using DTO;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BUS
{
    public class BUS_prod
    {
        DAL_Product dal_pro = new DAL_Product();
        public DataTable getProd()
        {
            return dal_pro.getProd();
        }
        public bool Insert_SanPham(DTO_product  prod)
        {
            return dal_pro.Insert_SanPham(prod);
        }
        public bool Update_SanPham (DTO_product prod)
        {
            return dal_pro.Update_SanPham(prod);
        }
    }
}
