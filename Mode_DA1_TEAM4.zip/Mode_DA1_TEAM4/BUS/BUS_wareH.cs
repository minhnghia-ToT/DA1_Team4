﻿using DAL;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BUS
{
    public class BUS_wareH
    {
      DAL_wareH dAL_WareH = new DAL_wareH();

        public DataTable GetKhoData()
        {
            return dAL_WareH.GetKhoData();
        }
        public DataTable seach_Kho(string key)
        {
            return dAL_WareH.seach_Kho(key);
        }
    }
}
